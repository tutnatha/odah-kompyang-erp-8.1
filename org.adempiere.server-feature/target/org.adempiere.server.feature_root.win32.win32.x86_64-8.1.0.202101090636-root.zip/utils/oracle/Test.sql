-- Connection Test
SELECT 'Success    ' AS Connection FROM DUAL
/
EXIT

