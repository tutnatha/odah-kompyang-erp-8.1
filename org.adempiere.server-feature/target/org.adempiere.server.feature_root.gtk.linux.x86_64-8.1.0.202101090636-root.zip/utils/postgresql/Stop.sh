#!/bin/sh

echo Stop Oracle DB Service

# $Id: Stop.sh,v 1.2 2002/04/24 01:52:59 jjanke Exp $

pg_ctl stop


