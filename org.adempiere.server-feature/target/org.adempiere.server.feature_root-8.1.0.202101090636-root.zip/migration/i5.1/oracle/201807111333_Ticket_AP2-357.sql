-- just for postgresql

SELECT register_migration_script('201807111333_Ticket_AP2-357.sql') FROM dual
;
