ALTER FUNCTION documentNo(numeric) OWNER TO adempiere;
SELECT register_migration_script('202001211654_IDEMPIERE-4143.sql') FROM dual
;

