-- IDEMPIERE-3413 Multi Select List and table reference
-- Placeholder - script just for oracle

SELECT register_migration_script('201912282330_IDEMPIERE-3413.sql') FROM dual
;

