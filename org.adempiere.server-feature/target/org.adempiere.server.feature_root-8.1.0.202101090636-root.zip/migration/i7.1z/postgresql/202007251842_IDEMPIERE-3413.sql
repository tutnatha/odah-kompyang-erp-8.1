-- IDEMPIERE-3413 Multi Select List and table reference
-- Jul 25, 2020, 5:52:43 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=197,Updated=TO_TIMESTAMP('2020-07-25 17:52:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=383
;

-- Jul 25, 2020, 5:53:07 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163,Updated=TO_TIMESTAMP('2020-07-25 17:53:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=385
;

-- Jul 25, 2020, 5:53:56 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162,Updated=TO_TIMESTAMP('2020-07-25 17:53:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=386
;

-- Jul 25, 2020, 6:00:32 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138,Updated=TO_TIMESTAMP('2020-07-25 18:00:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=617
;

-- Jul 25, 2020, 6:01:45 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=200045,Updated=TO_TIMESTAMP('2020-07-25 18:01:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=677
;

-- Jul 25, 2020, 6:14:08 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138,Updated=TO_TIMESTAMP('2020-07-25 18:14:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=591
;

-- Jul 25, 2020, 6:14:34 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138,Updated=TO_TIMESTAMP('2020-07-25 18:14:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=590
;

-- Jul 25, 2020, 6:15:10 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200161,Updated=TO_TIMESTAMP('2020-07-25 18:15:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=679
;

-- Jul 25, 2020, 6:15:26 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:15:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=676
;

-- Jul 25, 2020, 6:16:02 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=170,Updated=TO_TIMESTAMP('2020-07-25 18:16:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=611
;

-- Jul 25, 2020, 6:16:52 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=276,Updated=TO_TIMESTAMP('2020-07-25 18:16:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=373
;

-- Jul 25, 2020, 6:17:10 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=276,Updated=TO_TIMESTAMP('2020-07-25 18:17:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=370
;

-- Jul 25, 2020, 6:17:20 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=200045,Updated=TO_TIMESTAMP('2020-07-25 18:17:20','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=175
;

-- Jul 25, 2020, 6:17:44 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:17:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=176
;

-- Jul 25, 2020, 6:17:49 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200161,Updated=TO_TIMESTAMP('2020-07-25 18:17:49','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=371
;

-- Jul 25, 2020, 6:18:10 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:18:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=161
;

-- Jul 25, 2020, 6:18:25 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163,Updated=TO_TIMESTAMP('2020-07-25 18:18:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=601
;

-- Jul 25, 2020, 6:18:48 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:18:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=163
;

-- Jul 25, 2020, 6:18:54 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163,Updated=TO_TIMESTAMP('2020-07-25 18:18:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=602
;

-- Jul 25, 2020, 6:19:08 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:19:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=595
;

-- Jul 25, 2020, 6:19:23 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=200045,Updated=TO_TIMESTAMP('2020-07-25 18:19:23','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=177
;

-- Jul 25, 2020, 6:19:35 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:19:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=178
;

-- Jul 25, 2020, 6:19:47 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:19:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=179
;

-- Jul 25, 2020, 6:20:13 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:20:13','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=180
;

-- Jul 25, 2020, 6:20:25 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:20:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=599
;

-- Jul 25, 2020, 6:20:40 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163,Updated=TO_TIMESTAMP('2020-07-25 18:20:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=606
;

-- Jul 25, 2020, 6:21:06 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162,Updated=TO_TIMESTAMP('2020-07-25 18:21:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=707
;

-- Jul 25, 2020, 6:21:33 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162,Updated=TO_TIMESTAMP('2020-07-25 18:21:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=704
;

-- Jul 25, 2020, 6:21:50 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163,Updated=TO_TIMESTAMP('2020-07-25 18:21:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=604
;

-- Jul 25, 2020, 6:22:09 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=276,Updated=TO_TIMESTAMP('2020-07-25 18:22:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=426
;

-- Jul 25, 2020, 6:22:20 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=158,Updated=TO_TIMESTAMP('2020-07-25 18:22:20','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=427
;

-- Jul 25, 2020, 6:22:31 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=170,Updated=TO_TIMESTAMP('2020-07-25 18:22:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=428
;

-- Jul 25, 2020, 6:22:42 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163,Updated=TO_TIMESTAMP('2020-07-25 18:22:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=607
;

-- Jul 25, 2020, 6:22:52 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163,Updated=TO_TIMESTAMP('2020-07-25 18:22:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=608
;

-- Jul 25, 2020, 6:23:02 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:23:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=597
;

-- Jul 25, 2020, 6:23:57 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162,Updated=TO_TIMESTAMP('2020-07-25 18:23:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=653
;

-- Jul 25, 2020, 6:24:07 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163,Updated=TO_TIMESTAMP('2020-07-25 18:24:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=652
;

-- Jul 25, 2020, 6:24:31 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163,Updated=TO_TIMESTAMP('2020-07-25 18:24:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=661
;

-- Jul 25, 2020, 6:24:46 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162,Updated=TO_TIMESTAMP('2020-07-25 18:24:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=662
;

-- Jul 25, 2020, 6:25:03 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163,Updated=TO_TIMESTAMP('2020-07-25 18:25:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=657
;

-- Jul 25, 2020, 6:25:15 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162,Updated=TO_TIMESTAMP('2020-07-25 18:25:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=658
;

-- Jul 25, 2020, 6:25:56 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:25:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=429
;

-- Jul 25, 2020, 6:26:17 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=275,Updated=TO_TIMESTAMP('2020-07-25 18:26:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=434
;

-- Jul 25, 2020, 6:26:24 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:26:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=437
;

-- Jul 25, 2020, 6:28:22 PM CEST
INSERT INTO AD_Reference (AD_Reference_ID,Name,ValidationType,AD_Client_ID,AD_Org_ID,IsActive,Created,CreatedBy,Updated,UpdatedBy,EntityType,IsOrderByValue,AD_Reference_UU) VALUES (200175,'C_BPartner (all)','T',0,0,'Y',TO_TIMESTAMP('2020-07-25 18:28:22','YYYY-MM-DD HH24:MI:SS'),100,TO_TIMESTAMP('2020-07-25 18:28:22','YYYY-MM-DD HH24:MI:SS'),100,'D','N','9464f6b3-d548-48c9-aaad-0c4ea9b5afd7')
;

-- Jul 25, 2020, 6:28:45 PM CEST
INSERT INTO AD_Ref_Table (AD_Reference_ID,AD_Table_ID,AD_Key,AD_Display,AD_Client_ID,AD_Org_ID,IsActive,Created,CreatedBy,Updated,UpdatedBy,IsValueDisplayed,EntityType,AD_Ref_Table_UU) VALUES (200175,291,2893,2902,0,0,'Y',TO_TIMESTAMP('2020-07-25 18:28:45','YYYY-MM-DD HH24:MI:SS'),100,TO_TIMESTAMP('2020-07-25 18:28:45','YYYY-MM-DD HH24:MI:SS'),100,'N','D','e00d8998-afee-4c90-a907-3f7fdc3c4510')
;

-- Jul 25, 2020, 6:29:07 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=200175,Updated=TO_TIMESTAMP('2020-07-25 18:29:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=439
;

-- Jul 25, 2020, 6:30:14 PM CEST
INSERT INTO AD_Reference (AD_Reference_ID,Name,ValidationType,AD_Client_ID,AD_Org_ID,IsActive,Created,CreatedBy,Updated,UpdatedBy,EntityType,IsOrderByValue,AD_Reference_UU) VALUES (200176,'M_Product (all)','T',0,0,'Y',TO_TIMESTAMP('2020-07-25 18:30:14','YYYY-MM-DD HH24:MI:SS'),100,TO_TIMESTAMP('2020-07-25 18:30:14','YYYY-MM-DD HH24:MI:SS'),100,'D','N','79ad8bb4-64c7-42d7-993e-853a2c99ea76')
;

-- Jul 25, 2020, 6:30:44 PM CEST
INSERT INTO AD_Ref_Table (AD_Reference_ID,AD_Table_ID,AD_Key,AD_Display,AD_Client_ID,AD_Org_ID,IsActive,Created,CreatedBy,Updated,UpdatedBy,IsValueDisplayed,EntityType,AD_Ref_Table_UU) VALUES (200176,208,1402,1410,0,0,'Y',TO_TIMESTAMP('2020-07-25 18:30:44','YYYY-MM-DD HH24:MI:SS'),100,TO_TIMESTAMP('2020-07-25 18:30:44','YYYY-MM-DD HH24:MI:SS'),100,'N','D','7e334f46-1320-4200-ad9d-b0913fba7c46')
;

-- Jul 25, 2020, 6:30:57 PM CEST
UPDATE AD_Ref_Table SET IsValueDisplayed='Y',Updated=TO_TIMESTAMP('2020-07-25 18:30:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Reference_ID=200176
;

-- Jul 25, 2020, 6:31:07 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=200176,Updated=TO_TIMESTAMP('2020-07-25 18:31:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=440
;

-- Jul 25, 2020, 6:31:18 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=158,Updated=TO_TIMESTAMP('2020-07-25 18:31:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=441
;

-- Jul 25, 2020, 6:31:39 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:31:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=431
;

-- Jul 25, 2020, 6:31:44 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:31:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=443
;

-- Jul 25, 2020, 6:31:50 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=158,Updated=TO_TIMESTAMP('2020-07-25 18:31:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=446
;

-- Jul 25, 2020, 6:32:03 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=275,Updated=TO_TIMESTAMP('2020-07-25 18:32:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=435
;

-- Jul 25, 2020, 6:32:17 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=200175,Updated=TO_TIMESTAMP('2020-07-25 18:32:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=444
;

-- Jul 25, 2020, 6:32:25 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=200176,Updated=TO_TIMESTAMP('2020-07-25 18:32:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=445
;

-- Jul 25, 2020, 6:32:46 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:32:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=430
;

-- Jul 25, 2020, 6:32:52 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:32:52','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=448
;

-- Jul 25, 2020, 6:32:59 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=158,Updated=TO_TIMESTAMP('2020-07-25 18:32:59','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=451
;

-- Jul 25, 2020, 6:33:06 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=275,Updated=TO_TIMESTAMP('2020-07-25 18:33:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=436
;

-- Jul 25, 2020, 6:33:18 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=200175,Updated=TO_TIMESTAMP('2020-07-25 18:33:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=449
;

-- Jul 25, 2020, 6:33:24 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=200176,Updated=TO_TIMESTAMP('2020-07-25 18:33:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=450
;

-- Jul 25, 2020, 6:33:39 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:33:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=200057
;

-- Jul 25, 2020, 6:33:43 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162,Updated=TO_TIMESTAMP('2020-07-25 18:33:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=200058
;

-- Jul 25, 2020, 6:34:00 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138,Updated=TO_TIMESTAMP('2020-07-25 18:34:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=506
;

-- Jul 25, 2020, 6:34:30 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138,Updated=TO_TIMESTAMP('2020-07-25 18:34:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=531
;

-- Jul 25, 2020, 6:34:42 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=197,Updated=TO_TIMESTAMP('2020-07-25 18:34:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=530
;

-- Jul 25, 2020, 6:34:57 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=197,Updated=TO_TIMESTAMP('2020-07-25 18:34:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=533
;

-- Jul 25, 2020, 6:35:08 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138,Updated=TO_TIMESTAMP('2020-07-25 18:35:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=534
;

-- Jul 25, 2020, 6:35:15 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200161,Updated=TO_TIMESTAMP('2020-07-25 18:35:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=537
;

-- Jul 25, 2020, 6:35:26 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=197,Updated=TO_TIMESTAMP('2020-07-25 18:35:26','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=508
;

-- Jul 25, 2020, 6:35:31 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200161,Updated=TO_TIMESTAMP('2020-07-25 18:35:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=509
;

-- Jul 25, 2020, 6:35:40 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138,Updated=TO_TIMESTAMP('2020-07-25 18:35:40','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=510
;

-- Jul 25, 2020, 6:36:15 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=197,Updated=TO_TIMESTAMP('2020-07-25 18:36:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=479
;

-- Jul 25, 2020, 6:36:19 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163,Updated=TO_TIMESTAMP('2020-07-25 18:36:19','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=480
;

-- Jul 25, 2020, 6:36:25 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=200176,Updated=TO_TIMESTAMP('2020-07-25 18:36:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=481
;

-- Jul 25, 2020, 6:36:43 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:36:43','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=189
;

-- Jul 25, 2020, 6:36:48 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:36:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=190
;

-- Jul 25, 2020, 6:37:02 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=197, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:37:02','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=133
;

-- Jul 25, 2020, 6:37:08 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200161, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:37:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=134
;

-- Jul 25, 2020, 6:37:21 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:37:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=139
;

-- Jul 25, 2020, 6:37:35 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:37:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=172
;

-- Jul 25, 2020, 6:37:44 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200161,Updated=TO_TIMESTAMP('2020-07-25 18:37:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=719
;

-- Jul 25, 2020, 6:37:58 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=170,Updated=TO_TIMESTAMP('2020-07-25 18:37:58','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=670
;

-- Jul 25, 2020, 6:38:09 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138,Updated=TO_TIMESTAMP('2020-07-25 18:38:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=671
;

-- Jul 25, 2020, 6:38:18 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162,Updated=TO_TIMESTAMP('2020-07-25 18:38:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=672
;

-- Jul 25, 2020, 6:38:30 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:38:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=240
;

-- Jul 25, 2020, 6:38:38 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:38:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=241
;

-- Jul 25, 2020, 6:38:57 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=53283,Updated=TO_TIMESTAMP('2020-07-25 18:38:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=612
;

-- Jul 25, 2020, 6:39:07 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138,Updated=TO_TIMESTAMP('2020-07-25 18:39:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=613
;

-- Jul 25, 2020, 6:39:16 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=170,Updated=TO_TIMESTAMP('2020-07-25 18:39:16','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=614
;

-- Jul 25, 2020, 6:39:31 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=138, IsCentrallyMaintained='N',Updated=TO_TIMESTAMP('2020-07-25 18:39:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=174
;

-- Jul 25, 2020, 6:40:41 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=130,Updated=TO_TIMESTAMP('2020-07-25 18:40:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53364
;

-- Jul 25, 2020, 6:40:47 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163,Updated=TO_TIMESTAMP('2020-07-25 18:40:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53362
;

-- Jul 25, 2020, 6:40:55 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=162,Updated=TO_TIMESTAMP('2020-07-25 18:40:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=53363
;

-- Jul 25, 2020, 6:41:06 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=163,Updated=TO_TIMESTAMP('2020-07-25 18:41:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=391
;

-- Jul 25, 2020, 6:41:15 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200163, AD_Reference_Value_ID=162,Updated=TO_TIMESTAMP('2020-07-25 18:41:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=392
;

-- Jul 25, 2020, 6:41:33 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200162, AD_Reference_Value_ID=53283,Updated=TO_TIMESTAMP('2020-07-25 18:41:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=592
;

-- Jul 25, 2020, 6:41:42 PM CEST
UPDATE AD_Process_Para SET AD_Reference_ID=200161,Updated=TO_TIMESTAMP('2020-07-25 18:41:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Process_Para_ID=610
;

SELECT register_migration_script('202007251842_IDEMPIERE-3413.sql') FROM dual
;

