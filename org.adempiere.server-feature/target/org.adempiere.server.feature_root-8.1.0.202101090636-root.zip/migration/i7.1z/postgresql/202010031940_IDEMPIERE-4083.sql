-- IDEMPIERE-4083 currency rate by document or by transaction
-- placeholder - this is just for oracle

SELECT register_migration_script('202010031940_IDEMPIERE-4083.sql') FROM dual
;

