UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55838 /*A_Asset_Change.A_Parent_Asset_ID->A_Asset*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55655 /*A_Asset_Disposed.A_Asset_Trade_ID->A_Asset*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8084 /*A_Asset_Retirement.A_Asset_ID->A_Asset*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55590 /*A_Asset_Split.A_Asset_ID_To->A_Asset*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55695 /*A_Depreciation_Build.A_End_Asset_ID->A_Asset*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55708 /*A_Depreciation_Build.A_Start_Asset_ID->A_Asset*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55496 /*A_Depreciation_Forecast.A_End_Asset_ID->A_Asset*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55506 /*A_Depreciation_Forecast.A_Start_Asset_ID->A_Asset*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14667 /*AD_Issue.A_Asset_ID->A_Asset*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13903 /*M_OperationResource.A_Asset_ID->A_Asset*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205507 /*T_InvoiceGL_v.A_Asset_ID->A_Asset*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12966 /*T_TrialBalance.A_Asset_ID->A_Asset*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59336 /*A_Depreciation_Exp.A_Asset_Addition_ID->A_Asset_Addition*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59337 /*A_Depreciation_Exp.A_Asset_Disposed_ID->A_Asset_Disposed*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208566 /*AD_CtxHelpMsg.AD_CtxHelp_ID->AD_CtxHelp*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212798 /*AD_CtxHelpSuggestion.AD_CtxHelp_ID->AD_CtxHelp*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208590 /*AD_Form.AD_CtxHelp_ID->AD_CtxHelp*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208591 /*AD_InfoWindow.AD_CtxHelp_ID->AD_CtxHelp*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208592 /*AD_Process.AD_CtxHelp_ID->AD_CtxHelp*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208589 /*AD_Tab.AD_CtxHelp_ID->AD_CtxHelp*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208593 /*AD_Task.AD_CtxHelp_ID->AD_CtxHelp*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208804 /*AD_WF_Node.AD_CtxHelp_ID->AD_CtxHelp*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208594 /*AD_Workflow.AD_CtxHelp_ID->AD_CtxHelp*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208569 /*AD_CtxHelpMsg_Trl.AD_CtxHelpMsg_ID->AD_CtxHelpMsg*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212799 /*AD_CtxHelpSuggestion.AD_CtxHelpMsg_ID->AD_CtxHelpMsg*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2637 /*AD_Element_Trl.AD_Element_ID->AD_Element*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6767 /*AD_Message_Trl.AD_Message_ID->AD_Message*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6768 /*AD_Note.AD_Message_ID->AD_Message*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50213 /*AD_Package_Exp_Detail.AD_Message_ID->AD_Message*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210909 /*AD_StatusLine.AD_Message_ID->AD_Message*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210590 /*AD_TableIndex.AD_Message_ID->AD_Message*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10453 /*AD_WF_Activity.AD_Message_ID->AD_Message*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10471 /*AD_WF_Process.AD_Message_ID->AD_Message*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8780 /*AD_PInstance_Log.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2787 /*AD_PInstance_Para.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54324 /*RV_PP_Product_BOMLine.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208646 /*RV_T_1099Extract.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208614 /*T_1099Extract.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10143 /*T_Aging.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208717 /*T_BankRegister.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62007 /*T_BOM_Indented.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54074 /*T_BOMLine.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56639 /*T_BOMLine_Costs.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60210 /*T_CashFlow.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7047 /*T_InventoryValue.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14077 /*T_InvoiceGL.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14023 /*T_InvoiceGL_v.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54063 /*T_MRP_CRP.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59780 /*T_Reconciliation.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7045 /*T_Replenish.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8155 /*T_Report.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8191 /*T_ReportStatement.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59750 /*T_RV_Reconciliation.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4423 /*T_Spool.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13005 /*T_TrialBalance.AD_PInstance_ID->AD_PInstance*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8813 /*AD_ChangeLog.AD_Session_ID->AD_Session*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8045 /*A_Asset.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8063 /*A_Asset.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55619 /*A_Asset_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55614 /*A_Asset_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55967 /*A_Asset_Addition.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55961 /*A_Asset_Addition.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55859 /*A_Asset_Change.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55865 /*A_Asset_Change.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59356 /*A_Asset_Class.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59358 /*A_Asset_Class.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8089 /*A_Asset_Delivery.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8104 /*A_Asset_Delivery.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55644 /*A_Asset_Disposed.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55647 /*A_Asset_Disposed.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8109 /*A_Asset_Group.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8116 /*A_Asset_Group.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55780 /*A_Asset_Group_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55774 /*A_Asset_Group_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211017 /*A_Asset_Group_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211020 /*A_Asset_Group_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55813 /*A_Asset_Info_Fin.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55814 /*A_Asset_Info_Fin.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55917 /*A_Asset_Info_Ins.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55919 /*A_Asset_Info_Ins.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55906 /*A_Asset_Info_Lic.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55904 /*A_Asset_Info_Lic.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55947 /*A_Asset_Info_Oth.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55951 /*A_Asset_Info_Oth.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55800 /*A_Asset_Info_Tax.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55798 /*A_Asset_Info_Tax.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59269 /*A_Asset_Product.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59271 /*A_Asset_Product.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8075 /*A_Asset_Retirement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8082 /*A_Asset_Retirement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59415 /*A_Asset_Reval.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59426 /*A_Asset_Reval.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55515 /*A_Asset_Reval_Entry.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55517 /*A_Asset_Reval_Entry.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55541 /*A_Asset_Reval_Index.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55539 /*A_Asset_Reval_Index.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55582 /*A_Asset_Split.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55575 /*A_Asset_Split.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55682 /*A_Asset_Transfer.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55675 /*A_Asset_Transfer.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59439 /*A_Asset_Type.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59441 /*A_Asset_Type.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55975 /*A_Asset_Use.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55977 /*A_Asset_Use.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11864 /*AD_AccessLog.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11868 /*AD_AccessLog.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9081 /*AD_Alert.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9080 /*AD_Alert.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11431 /*AD_AlertProcessor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11430 /*AD_AlertProcessor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11425 /*AD_AlertProcessorLog.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11420 /*AD_AlertProcessorLog.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9043 /*AD_AlertRecipient.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9051 /*AD_AlertRecipient.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9053 /*AD_AlertRule.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9060 /*AD_AlertRule.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213150 /*AD_AllClients_V.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213152 /*AD_AllClients_V.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213876 /*AD_AllRoles_V.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213878 /*AD_AllRoles_V.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213832 /*AD_AllUserRoles_V.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213834 /*AD_AllUserRoles_V.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213164 /*AD_AllUsers_V.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213166 /*AD_AllUsers_V.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13064 /*AD_Archive.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13066 /*AD_Archive.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2092 /*AD_Attachment.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2094 /*AD_Attachment.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11538 /*AD_AttachmentNote.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11537 /*AD_AttachmentNote.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5175 /*AD_Attribute.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5177 /*AD_Attribute.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200981 /*AD_BroadcastMessage.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200983 /*AD_BroadcastMessage.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211145 /*AD_BroadcastMessage_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211148 /*AD_BroadcastMessage_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8806 /*AD_ChangeLog.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8812 /*AD_ChangeLog.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59691 /*AD_Chart.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59693 /*AD_Chart.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59672 /*AD_ChartDatasource.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59684 /*AD_ChartDatasource.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211132 /*AD_Chart_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211135 /*AD_Chart_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=619 /*AD_Client.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=621 /*AD_Client.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1987 /*AD_ClientInfo.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1989 /*AD_ClientInfo.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14625 /*AD_ClientShare.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14627 /*AD_ClientShare.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6227 /*AD_Color.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6229 /*AD_Color.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211031 /*AD_Color_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211034 /*AD_Color_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=550 /*AD_Column.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=552 /*AD_Column.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8643 /*AD_Column_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8640 /*AD_Column_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12956 /*AD_Column_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12958 /*AD_Column_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208536 /*AD_CtxHelp.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208543 /*AD_CtxHelp.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208556 /*AD_CtxHelpMsg.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208563 /*AD_CtxHelpMsg.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208573 /*AD_CtxHelpMsg_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208579 /*AD_CtxHelpMsg_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212805 /*AD_CtxHelpSuggestion.AD_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212807 /*AD_CtxHelpSuggestion.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212813 /*AD_CtxHelpSuggestion.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6251 /*AD_Desktop.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6253 /*AD_Desktop.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6276 /*AD_Desktop_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6278 /*AD_Desktop_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6264 /*AD_DesktopWorkbench.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6266 /*AD_DesktopWorkbench.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53226 /*AD_Document_Action_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53228 /*AD_Document_Action_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2599 /*AD_Element.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2601 /*AD_Element.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2643 /*AD_Element_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2645 /*AD_Element_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15598 /*AD_EntityType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15600 /*AD_EntityType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55342 /*A_Depreciation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55350 /*A_Depreciation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55697 /*A_Depreciation_Build.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55702 /*A_Depreciation_Build.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55734 /*A_Depreciation_Convention.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55738 /*A_Depreciation_Convention.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55550 /*A_Depreciation_Entry.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55554 /*A_Depreciation_Entry.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55391 /*A_Depreciation_Exp.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55386 /*A_Depreciation_Exp.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55505 /*A_Depreciation_Forecast.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55501 /*A_Depreciation_Forecast.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55752 /*A_Depreciation_Method.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55749 /*A_Depreciation_Method.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55360 /*A_Depreciation_Table_Detail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55358 /*A_Depreciation_Table_Detail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55368 /*A_Depreciation_Table_Header.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55371 /*A_Depreciation_Table_Header.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55408 /*A_Depreciation_Workfile.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55413 /*A_Depreciation_Workfile.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4662 /*AD_Error.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4664 /*AD_Error.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=580 /*AD_Field.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=582 /*AD_Field.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5381 /*AD_FieldGroup.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5383 /*AD_FieldGroup.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5391 /*AD_FieldGroup_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5393 /*AD_FieldGroup_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212780 /*AD_FieldSuggestion.AD_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212773 /*AD_FieldSuggestion.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212776 /*AD_FieldSuggestion.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=673 /*AD_Field_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=675 /*AD_Field_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6130 /*AD_Find.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6132 /*AD_Find.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4601 /*AD_Form.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4603 /*AD_Form.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4629 /*AD_Form_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4631 /*AD_Form_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4614 /*AD_Form_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4616 /*AD_Form_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56330 /*AD_HouseKeeping.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56337 /*AD_HouseKeeping.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6292 /*AD_Image.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6294 /*AD_Image.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4673 /*AD_ImpFormat.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4675 /*AD_ImpFormat.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4686 /*AD_ImpFormat_Row.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4688 /*AD_ImpFormat_Row.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211772 /*AD_ImportTemplate.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211777 /*AD_ImportTemplate.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211788 /*AD_ImportTemplateAccess.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211794 /*AD_ImportTemplateAccess.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210537 /*AD_IndexColumn.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210543 /*AD_IndexColumn.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15778 /*AD_InfoColumn.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15780 /*AD_InfoColumn.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15798 /*AD_InfoColumn_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15800 /*AD_InfoColumn_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211247 /*AD_InfoProcess.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211249 /*AD_InfoProcess.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210602 /*AD_InfoRelated.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210604 /*AD_InfoRelated.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15749 /*AD_InfoWindow.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15751 /*AD_InfoWindow.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208370 /*AD_InfoWindow_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208375 /*AD_InfoWindow_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15766 /*AD_InfoWindow_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15768 /*AD_InfoWindow_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14652 /*AD_Issue.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14654 /*AD_Issue.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9934 /*AD_LabelPrinter.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9929 /*AD_LabelPrinter.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9890 /*AD_LabelPrinterFunction.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9904 /*AD_LabelPrinterFunction.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=614 /*AD_Language.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=616 /*AD_Language.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15966 /*AD_LdapAccess.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15968 /*AD_LdapAccess.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15934 /*AD_LdapProcessor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15943 /*AD_LdapProcessor.Supervisor_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15936 /*AD_LdapProcessor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15951 /*AD_LdapProcessorLog.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15953 /*AD_LdapProcessorLog.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=600 /*AD_Menu.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=602 /*AD_Menu.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=638 /*AD_Menu_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=640 /*AD_Menu_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=590 /*AD_Message.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=592 /*AD_Message.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=610 /*AD_Message_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=612 /*AD_Message_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54365 /*AD_MigrationScript.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54367 /*AD_MigrationScript.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53256 /*AD_ModelValidator.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53258 /*AD_ModelValidator.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15613 /*AD_Modification.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15615 /*AD_Modification.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4830 /*AD_Note.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4832 /*AD_Note.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=713 /*AD_Org.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=715 /*AD_Org.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1997 /*AD_OrgInfo.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1999 /*AD_OrgInfo.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11269 /*AD_OrgType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11274 /*AD_OrgType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50083 /*AD_Package_Exp.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50091 /*AD_Package_Exp.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50116 /*AD_Package_Exp_Detail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50118 /*AD_Package_Exp_Detail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50060 /*AD_Package_Imp.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50051 /*AD_Package_Imp.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50034 /*AD_Package_Imp_Backup.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50032 /*AD_Package_Imp_Backup.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50071 /*AD_Package_Imp_Detail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50079 /*AD_Package_Imp_Detail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50006 /*AD_Package_Imp_Inst.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50012 /*AD_Package_Imp_Inst.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50175 /*AD_Package_Imp_Proc.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50179 /*AD_Package_Imp_Proc.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210838 /*AD_Package_UUID_Map.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210841 /*AD_Package_UUID_Map.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212115 /*AD_Password_History.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212117 /*AD_Password_History.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200118 /*AD_PasswordRule.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200120 /*AD_PasswordRule.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8224 /*AD_PInstance.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8222 /*AD_PInstance.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8227 /*AD_PInstance_Para.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8230 /*AD_PInstance_Para.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1271 /*AD_Preference.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1273 /*AD_Preference.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6972 /*AD_PrintColor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6981 /*AD_PrintColor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211043 /*AD_PrintColor_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211046 /*AD_PrintColor_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6993 /*AD_PrintFont.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6985 /*AD_PrintFont.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6183 /*AD_PrintForm.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6185 /*AD_PrintForm.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7008 /*AD_PrintFormat.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7016 /*AD_PrintFormat.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6955 /*AD_PrintFormatItem.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6952 /*AD_PrintFormatItem.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7609 /*AD_PrintFormatItem_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7606 /*AD_PrintFormatItem_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211265 /*AD_PrintFormat_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211267 /*AD_PrintFormat_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7589 /*AD_PrintGraph.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7591 /*AD_PrintGraph.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8627 /*AD_PrintLabel.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8631 /*AD_PrintLabel.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8614 /*AD_PrintLabelLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8612 /*AD_PrintLabelLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8599 /*AD_PrintLabelLine_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8598 /*AD_PrintLabelLine_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6999 /*AD_PrintPaper.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6995 /*AD_PrintPaper.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7629 /*AD_PrintTableFormat.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7637 /*AD_PrintTableFormat.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9938 /*AD_Private_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9945 /*AD_Private_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2806 /*AD_Process.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2808 /*AD_Process.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1292 /*AD_Process_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1294 /*AD_Process_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2819 /*AD_Process_Para.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2821 /*AD_Process_Para.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2837 /*AD_Process_Para_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2839 /*AD_Process_Para_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2849 /*AD_Process_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2851 /*AD_Process_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200009 /*AD_RecentItem.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200013 /*AD_RecentItem.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8588 /*AD_Record_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8595 /*AD_Record_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=555 /*AD_Reference.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=557 /*AD_Reference.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=668 /*AD_Reference_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=670 /*AD_Reference_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=565 /*AD_Ref_List.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=567 /*AD_Ref_List.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=708 /*AD_Ref_List_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=710 /*AD_Ref_List_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=560 /*AD_Ref_Table.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=562 /*AD_Ref_Table.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9910 /*AD_Registration.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9913 /*AD_Registration.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58576 /*AD_RelationType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58581 /*AD_RelationType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9403 /*AD_Replication.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9400 /*AD_Replication.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54479 /*AD_ReplicationDocument.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54481 /*AD_ReplicationDocument.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9388 /*AD_Replication_Log.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9378 /*AD_Replication_Log.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9374 /*AD_Replication_Run.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9376 /*AD_Replication_Run.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9363 /*AD_ReplicationStrategy.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9359 /*AD_ReplicationStrategy.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9346 /*AD_ReplicationTable.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9354 /*AD_ReplicationTable.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4389 /*AD_ReportView.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4391 /*AD_ReportView.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5657 /*AD_ReportView_Col.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5659 /*AD_ReportView_Col.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210940 /*AD_ReportView_Column.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210943 /*AD_ReportView_Column.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=718 /*AD_Role.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=720 /*AD_Role.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57944 /*AD_Role_Included.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57948 /*AD_Role_Included.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5512 /*AD_Role_OrgAccess.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5514 /*AD_Role_OrgAccess.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54244 /*AD_Rule.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54251 /*AD_Rule.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200475 /*AD_Schedule.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200477 /*AD_Schedule.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11254 /*AD_Scheduler.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11260 /*AD_Scheduler.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11240 /*AD_SchedulerLog.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11233 /*AD_SchedulerLog.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11399 /*AD_Scheduler_Para.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11400 /*AD_Scheduler_Para.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11511 /*AD_SchedulerRecipient.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11513 /*AD_SchedulerRecipient.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56806 /*AD_SearchDefinition.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56815 /*AD_SearchDefinition.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=628 /*AD_Sequence.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=630 /*AD_Sequence.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=643 /*AD_Sequence_Audit.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=645 /*AD_Sequence_Audit.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=648 /*AD_Sequence_No.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=650 /*AD_Sequence_No.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8577 /*AD_Session.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8581 /*AD_Session.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210903 /*AD_StatusLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210908 /*AD_StatusLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210917 /*AD_StatusLineUsedIn.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210920 /*AD_StatusLineUsedIn.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200965 /*AD_StorageProvider.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200967 /*AD_StorageProvider.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212730 /*AD_Style.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212733 /*AD_Style.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212741 /*AD_StyleLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212744 /*AD_StyleLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50192 /*AD_SysConfig.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=50193 /*AD_SysConfig.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7809 /*AD_System.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7805 /*AD_System.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=575 /*AD_Tab.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=577 /*AD_Tab.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200260 /*AD_Tab_Customization.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200264 /*AD_Tab_Customization.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=545 /*AD_Table.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=547 /*AD_Table.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8567 /*AD_Table_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8569 /*AD_Table_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210518 /*AD_TableIndex.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210524 /*AD_TableIndex.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54263 /*AD_Table_ScriptValidator.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54270 /*AD_Table_ScriptValidator.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12717 /*AD_Table_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12718 /*AD_Table_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=653 /*AD_Tab_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=655 /*AD_Tab_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=605 /*AD_Task.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=607 /*AD_Task.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1312 /*AD_Task_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1314 /*AD_Task_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4838 /*AD_TaskInstance.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4839 /*AD_TaskInstance.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=658 /*AD_Task_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=660 /*AD_Task_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200086 /*AD_ToolBarButton.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200093 /*AD_ToolBarButton.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200103 /*AD_ToolBarButtonRestrict.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200110 /*AD_ToolBarButtonRestrict.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2860 /*AD_Tree.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2862 /*AD_Tree.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6209 /*AD_TreeBar.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6211 /*AD_TreeBar.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2872 /*AD_TreeNode.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2874 /*AD_TreeNode.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6141 /*AD_TreeNodeBP.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6143 /*AD_TreeNodeBP.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15030 /*AD_TreeNodeCMC.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15031 /*AD_TreeNodeCMC.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15041 /*AD_TreeNodeCMM.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15042 /*AD_TreeNodeCMM.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15052 /*AD_TreeNodeCMS.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15053 /*AD_TreeNodeCMS.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15063 /*AD_TreeNodeCMT.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15064 /*AD_TreeNodeCMT.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6152 /*AD_TreeNodeMM.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6154 /*AD_TreeNodeMM.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6169 /*AD_TreeNodePR.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6171 /*AD_TreeNodePR.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15107 /*AD_TreeNodeU1.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15108 /*AD_TreeNodeU1.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15096 /*AD_TreeNodeU2.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15097 /*AD_TreeNodeU2.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15085 /*AD_TreeNodeU3.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15086 /*AD_TreeNodeU3.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15074 /*AD_TreeNodeU4.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15075 /*AD_TreeNodeU4.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=624 /*AD_User.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=626 /*AD_User.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14342 /*AD_UserBPAccess.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14344 /*AD_UserBPAccess.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6341 /*AD_UserDef_Field.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6343 /*AD_UserDef_Field.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213266 /*AD_UserDef_Proc.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213268 /*AD_UserDef_Proc.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213284 /*AD_UserDef_Proc_Parameter.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213286 /*AD_UserDef_Proc_Parameter.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6376 /*AD_UserDef_Tab.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6378 /*AD_UserDef_Tab.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6392 /*AD_UserDef_Win.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6394 /*AD_UserDef_Win.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13695 /*AD_UserMail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13697 /*AD_UserMail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13443 /*AD_User_OrgAccess.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13445 /*AD_User_OrgAccess.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212162 /*AD_UserPreference.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212170 /*AD_UserPreference.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14354 /*AD_UserQuery.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14356 /*AD_UserQuery.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=723 /*AD_User_Roles.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=725 /*AD_User_Roles.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10417 /*AD_User_Substitute.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10416 /*AD_User_Substitute.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=585 /*AD_Val_Rule.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=587 /*AD_Val_Rule.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210576 /*AD_ViewColumn.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210582 /*AD_ViewColumn.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210555 /*AD_ViewComponent.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210561 /*AD_ViewComponent.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10442 /*AD_WF_Activity.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10451 /*AD_WF_Activity.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213227 /*AD_WF_ActivityApprover.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213231 /*AD_WF_ActivityApprover.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10527 /*AD_WF_ActivityResult.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10528 /*AD_WF_ActivityResult.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10489 /*AD_WF_Block.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10495 /*AD_WF_Block.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10518 /*AD_WF_EventAudit.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10514 /*AD_WF_EventAudit.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11564 /*AD_WF_NextCondition.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11574 /*AD_WF_NextCondition.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=683 /*AD_WF_Node.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=685 /*AD_WF_Node.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=693 /*AD_WF_NodeNext.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=695 /*AD_WF_NodeNext.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10427 /*AD_WF_Node_Para.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10436 /*AD_WF_Node_Para.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=688 /*AD_WF_Node_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=690 /*AD_WF_Node_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10464 /*AD_WF_Process.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10468 /*AD_WF_Process.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10499 /*AD_WF_ProcessData.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10500 /*AD_WF_ProcessData.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10474 /*AD_WF_Responsible.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10484 /*AD_WF_Responsible.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=570 /*AD_Window.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=572 /*AD_Window.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1335 /*AD_Window_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1337 /*AD_Window_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=698 /*AD_Window_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=700 /*AD_Window_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200309 /*AD_WizardProcess.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200317 /*AD_WizardProcess.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6410 /*AD_Workbench.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6412 /*AD_Workbench.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6441 /*AD_Workbench_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6443 /*AD_Workbench_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6425 /*AD_WorkbenchWindow.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6427 /*AD_WorkbenchWindow.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=633 /*AD_Workflow.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=635 /*AD_Workflow.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1345 /*AD_Workflow_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1347 /*AD_Workflow_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11390 /*AD_WorkflowProcessor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11385 /*AD_WorkflowProcessor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11378 /*AD_WorkflowProcessorLog.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11371 /*AD_WorkflowProcessorLog.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=703 /*AD_Workflow_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=705 /*AD_Workflow_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59374 /*A_FundingMode.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59377 /*A_FundingMode.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59384 /*A_FundingMode_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59387 /*A_FundingMode_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10603 /*A_Registration.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10591 /*A_Registration.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10614 /*A_RegistrationAttribute.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10613 /*A_RegistrationAttribute.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11824 /*A_RegistrationProduct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11827 /*A_RegistrationProduct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10618 /*A_RegistrationValue.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10617 /*A_RegistrationValue.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54226 /*ASP_ClientException.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54233 /*ASP_ClientException.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54213 /*ASP_ClientLevel.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54212 /*ASP_ClientLevel.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54126 /*ASP_Field.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54124 /*ASP_Field.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54157 /*ASP_Form.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54155 /*ASP_Form.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54198 /*ASP_Level.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54203 /*ASP_Level.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54185 /*ASP_Module.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54190 /*ASP_Module.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54136 /*ASP_Process.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54134 /*ASP_Process.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54147 /*ASP_Process_Para.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54145 /*ASP_Process_Para.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200297 /*ASP_Ref_List.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200298 /*ASP_Ref_List.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54114 /*ASP_Tab.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54112 /*ASP_Tab.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54167 /*ASP_Task.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54165 /*ASP_Task.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54102 /*ASP_Window.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54100 /*ASP_Window.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54177 /*ASP_Workflow.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54175 /*ASP_Workflow.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11228 /*B_Bid.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11219 /*B_Bid.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11208 /*B_BidComment.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11206 /*B_BidComment.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11198 /*B_Buyer.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11195 /*B_Buyer.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11186 /*B_BuyerFunds.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11192 /*B_BuyerFunds.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11170 /*B_Offer.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11181 /*B_Offer.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11163 /*B_Seller.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11157 /*B_Seller.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11146 /*B_SellerFunds.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11143 /*B_SellerFunds.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11125 /*B_Topic.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11138 /*B_Topic.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11290 /*B_TopicCategory.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11299 /*B_TopicCategory.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11286 /*B_TopicType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11281 /*B_TopicType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208691 /*C_1099Box.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208696 /*C_1099Box.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11352 /*C_AcctProcessor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11361 /*C_AcctProcessor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11339 /*C_AcctProcessorLog.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11332 /*C_AcctProcessorLog.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2468 /*C_AcctSchema.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2470 /*C_AcctSchema.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3440 /*C_AcctSchema_Default.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3442 /*C_AcctSchema_Default.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2660 /*C_AcctSchema_Element.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2662 /*C_AcctSchema_Element.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2487 /*C_AcctSchema_GL.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2489 /*C_AcctSchema_GL.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3462 /*C_Activity.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3464 /*C_Activity.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211055 /*C_Activity_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211058 /*C_Activity_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210780 /*C_AddressTransaction.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210786 /*C_AddressTransaction.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210758 /*C_AddressValidation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210765 /*C_AddressValidation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210736 /*C_AddressValidationCfg.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210751 /*C_AddressValidationCfg.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12325 /*C_AllocationHdr.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12321 /*C_AllocationHdr.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4879 /*C_AllocationLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4881 /*C_AllocationLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4896 /*C_BankAccount_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4898 /*C_BankAccount_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6193 /*C_BankAccountDoc.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6195 /*C_BankAccountDoc.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200691 /*C_BankAccount_Processor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200700 /*C_BankAccount_Processor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4914 /*C_BankStatement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4916 /*C_BankStatement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4931 /*C_BankStatementLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4933 /*C_BankStatementLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10359 /*C_BankStatementLoader.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10361 /*C_BankStatementLoader.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10777 /*C_BankStatementMatcher.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10774 /*C_BankStatementMatcher.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2898 /*C_BPartner.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2900 /*C_BPartner.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2955 /*C_BPartner_Location.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2957 /*C_BPartner_Location.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10162 /*C_BPartner_Product.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10168 /*C_BPartner_Product.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3100 /*C_BP_BankAccount.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3101 /*C_BP_BankAccount.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2415 /*C_BP_Customer_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2417 /*C_BP_Customer_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4450 /*C_BP_EDI.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4452 /*C_BP_EDI.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2425 /*C_BP_Employee_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2427 /*C_BP_Employee_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4966 /*C_BP_Group.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4968 /*C_BP_Group.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4979 /*C_BP_Group_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4981 /*C_BP_Group_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11117 /*C_BP_Relation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11111 /*C_BP_Relation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201159 /*C_BP_ShippingAcct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201172 /*C_BP_ShippingAcct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2435 /*C_BP_Vendor_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2437 /*C_BP_Vendor_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3119 /*C_BP_Withholding.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3121 /*C_BP_Withholding.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=775 /*C_Calendar.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=777 /*C_Calendar.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2575 /*C_Campaign.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2577 /*C_Campaign.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211069 /*C_Campaign_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211072 /*C_Campaign_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5246 /*C_Cash.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5248 /*C_Cash.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5265 /*C_CashBook.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5267 /*C_CashBook.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5276 /*C_CashBook_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5278 /*C_CashBook_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5288 /*C_CashLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5290 /*C_CashLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60165 /*C_CashPlan.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60176 /*C_CashPlan.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60194 /*C_CashPlanLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60186 /*C_CashPlanLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2589 /*C_Channel.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2591 /*C_Channel.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3338 /*C_Charge.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3340 /*C_Charge.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5009 /*C_Charge_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5011 /*C_Charge_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57159 /*C_Charge_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57166 /*C_Charge_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56306 /*C_ChargeType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56313 /*C_ChargeType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56321 /*C_ChargeType_DocType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56325 /*C_ChargeType_DocType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1111 /*C_City.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1113 /*C_City.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5672 /*C_Commission.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5674 /*C_Commission.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5689 /*C_CommissionAmt.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5691 /*C_CommissionAmt.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5832 /*C_CommissionDetail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5834 /*C_CommissionDetail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5705 /*C_CommissionLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5707 /*C_CommissionLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5807 /*C_CommissionRun.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5809 /*C_CommissionRun.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62459 /*C_ContactActivity.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62463 /*C_ContactActivity.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=783 /*C_Conversion_Rate.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=785 /*C_Conversion_Rate.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10270 /*C_ConversionType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10266 /*C_ConversionType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=946 /*C_Country.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=948 /*C_Country.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211624 /*C_CountryGroup.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211631 /*C_CountryGroup.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211603 /*C_CountryGroupCountry.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211611 /*C_CountryGroupCountry.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211639 /*C_CountryGroup_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211645 /*C_CountryGroup_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9609 /*C_Country_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9601 /*C_Country_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=793 /*C_Currency.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=795 /*C_Currency.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10278 /*C_Currency_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10280 /*C_Currency_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9623 /*C_Currency_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9630 /*C_Currency_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5726 /*C_Cycle.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5728 /*C_Cycle.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5737 /*C_CyclePhase.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5739 /*C_CyclePhase.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8967 /*C_CycleStep.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8957 /*C_CycleStep.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208401 /*C_DepositBatch.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208407 /*C_DepositBatch.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208425 /*C_DepositBatchLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208431 /*C_DepositBatchLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1506 /*C_DocType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1508 /*C_DocType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11875 /*C_DocTypeCounter.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11882 /*C_DocTypeCounter.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3131 /*C_DocType_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3133 /*C_DocType_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3142 /*C_Dunning.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3144 /*C_Dunning.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201408 /*C_Dunning_Header_v.AD_OrgInfo_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201421 /*C_Dunning_Header_v.AD_OrgInfo_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201387 /*C_Dunning_Header_v.AD_User_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201396 /*C_Dunning_Header_v.AD_User_Supervisor_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201398 /*C_Dunning_Header_v.AD_User_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201295 /*C_Dunning_Header_v.C_BPartner_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201349 /*C_Dunning_Header_v.C_BPartner_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201362 /*C_Dunning_Header_v.C_BPartner_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201341 /*C_Dunning_Header_v.C_BPartner_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201260 /*C_Dunning_Header_v.C_DunningRunEntry_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201264 /*C_Dunning_Header_v.C_DunningRunEntry_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201372 /*C_Dunning_Header_v.C_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201378 /*C_Dunning_Header_v.C_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12591 /*C_Dunning_Header_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201453 /*C_Dunning_Header_v.SalesRep_BPartner_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201499 /*C_Dunning_Header_v.SalesRep_BPartner_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201430 /*C_Dunning_Header_v.SalesRep_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201438 /*C_Dunning_Header_v.SalesRep_Supervisor_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201440 /*C_Dunning_Header_v.SalesRep_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12592 /*C_Dunning_Header_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3706 /*C_DunningLevel.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3708 /*C_DunningLevel.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3774 /*C_DunningLevel_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3776 /*C_DunningLevel_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201520 /*C_Dunning_Line_v.C_Invoice_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201544 /*C_Dunning_Line_v.C_Invoice_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201584 /*C_Dunning_Line_v.C_Payment_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201618 /*C_Dunning_Line_v.C_Payment_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12634 /*C_Dunning_Line_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12610 /*C_Dunning_Line_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7686 /*C_DunningRun.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7683 /*C_DunningRun.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7699 /*C_DunningRunEntry.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7701 /*C_DunningRunEntry.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7662 /*C_DunningRunLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7658 /*C_DunningRunLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=803 /*C_Element.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=805 /*C_Element.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1132 /*C_ElementValue.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1134 /*C_ElementValue.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3160 /*C_ElementValue_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3162 /*C_ElementValue_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4075 /*C_Greeting.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4077 /*C_Greeting.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4088 /*C_Greeting_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4090 /*C_Greeting_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5020 /*C_InterOrg_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5022 /*C_InterOrg_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3489 /*C_Invoice.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3491 /*C_Invoice.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13384 /*C_InvoiceBatch.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13382 /*C_InvoiceBatch.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13395 /*C_InvoiceBatchLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13397 /*C_InvoiceBatchLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203613 /*C_Invoice_Header_v.AD_OrgInfo_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203626 /*C_Invoice_Header_v.AD_OrgInfo_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203594 /*C_Invoice_Header_v.AD_User_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203602 /*C_Invoice_Header_v.AD_User_Supervisor_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203604 /*C_Invoice_Header_v.AD_User_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203661 /*C_Invoice_Header_v.BPartner_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203711 /*C_Invoice_Header_v.BPartner_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203503 /*C_Invoice_Header_v.BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203557 /*C_Invoice_Header_v.BP_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203570 /*C_Invoice_Header_v.BP_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210220 /*C_Invoice_Header_v.BP_SalesRep_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203549 /*C_Invoice_Header_v.BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203580 /*C_Invoice_Header_v.C_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203585 /*C_Invoice_Header_v.C_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7462 /*C_Invoice_Header_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203635 /*C_Invoice_Header_v.SalesRep_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203644 /*C_Invoice_Header_v.SalesRep_Supervisor_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203647 /*C_Invoice_Header_v.SalesRep_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7449 /*C_Invoice_Header_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3833 /*C_InvoiceLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3835 /*C_InvoiceLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205711 /*C_Invoice_LineTax_v.C_BP_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205720 /*C_Invoice_LineTax_v.C_BP_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205570 /*C_Invoice_LineTax_v.C_Invoice_AD_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205587 /*C_Invoice_LineTax_v.C_Invoice_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205624 /*C_Invoice_LineTax_v.C_Invoice_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7069 /*C_Invoice_LineTax_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205736 /*C_Invoice_LineTax_v.M_ASI_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205740 /*C_Invoice_LineTax_v.M_ASI_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205651 /*C_Invoice_LineTax_v.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205694 /*C_Invoice_LineTax_v.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205733 /*C_Invoice_LineTax_v.S_RAssignment_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7078 /*C_Invoice_LineTax_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8316 /*C_InvoicePaySchedule.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8311 /*C_InvoicePaySchedule.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2141 /*C_InvoiceSchedule.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2143 /*C_InvoiceSchedule.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3856 /*C_InvoiceTax.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3858 /*C_InvoiceTax.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13786 /*C_Job.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13788 /*C_Job.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13809 /*C_JobAssignment.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13811 /*C_JobAssignment.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13798 /*C_JobCategory.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13800 /*C_JobCategory.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13839 /*C_JobRemuneration.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13841 /*C_JobRemuneration.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13294 /*C_LandedCost.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13296 /*C_LandedCost.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13317 /*C_LandedCostAllocation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13319 /*C_LandedCostAllocation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=813 /*C_Location.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=815 /*C_Location.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15509 /*CM_Chat.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15511 /*CM_Chat.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15522 /*CM_ChatEntry.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15524 /*CM_ChatEntry.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15488 /*CM_ChatType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15490 /*CM_ChatType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15500 /*CM_ChatTypeUpdate.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15502 /*CM_ChatTypeUpdate.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15534 /*CM_ChatUpdate.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15536 /*CM_ChatUpdate.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=831 /*C_NonBusinessDay.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=833 /*C_NonBusinessDay.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200836 /*C_OnlineTrxHistory.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200844 /*C_OnlineTrxHistory.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62136 /*C_Opportunity.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62140 /*C_Opportunity.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2166 /*C_Order.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2168 /*C_Order.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206133 /*C_Order_Header_v.AD_OrgInfo_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206146 /*C_Order_Header_v.AD_OrgInfo_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205920 /*C_Order_Header_v.AD_User_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205930 /*C_Order_Header_v.AD_User_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206246 /*C_Order_Header_v.Bill_BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206299 /*C_Order_Header_v.Bill_BP_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206312 /*C_Order_Header_v.Bill_BP_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206294 /*C_Order_Header_v.Bill_BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206321 /*C_Order_Header_v.Bill_User_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11966 /*C_Order_Header_v.Bill_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206331 /*C_Order_Header_v.Bill_User_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205829 /*C_Order_Header_v.BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205883 /*C_Order_Header_v.BP_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205896 /*C_Order_Header_v.BP_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210239 /*C_Order_Header_v.BP_SalesRep_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205874 /*C_Order_Header_v.BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205906 /*C_Order_Header_v.C_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205911 /*C_Order_Header_v.C_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7091 /*C_Order_Header_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205759 /*C_Order_Header_v.DropShip_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206181 /*C_Order_Header_v.SalesRep_BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206231 /*C_Order_Header_v.SalesRep_BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206155 /*C_Order_Header_v.SalesRep_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206167 /*C_Order_Header_v.SalesRep_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7117 /*C_Order_Header_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210792 /*C_OrderLandedCost.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210797 /*C_OrderLandedCost.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210809 /*C_OrderLandedCostAllocation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210812 /*C_OrderLandedCostAllocation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2210 /*C_OrderLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2212 /*C_OrderLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203843 /*C_Order_LineTax_v.Bill_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204045 /*C_Order_LineTax_v.C_BPartner_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204102 /*C_Order_LineTax_v.C_BPartner_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204115 /*C_Order_LineTax_v.C_BPartner_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204022 /*C_Order_LineTax_v.C_BPartner_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204031 /*C_Order_LineTax_v.C_BPartner_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204096 /*C_Order_LineTax_v.C_BPartner_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203861 /*C_Order_LineTax_v.C_Order_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203912 /*C_Order_LineTax_v.C_Order_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7140 /*C_Order_LineTax_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203873 /*C_Order_LineTax_v.DropShip_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203921 /*C_Order_LineTax_v.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203974 /*C_Order_LineTax_v.M_Product_PO_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203995 /*C_Order_LineTax_v.M_Product_PO_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203965 /*C_Order_LineTax_v.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204008 /*C_Order_LineTax_v.S_ResourceAssignment_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7138 /*C_Order_LineTax_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60141 /*C_OrderPaySchedule.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60151 /*C_OrderPaySchedule.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58402 /*C_OrderSource.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58404 /*C_OrderSource.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3352 /*C_OrderTax.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3354 /*C_OrderTax.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8911 /*C_OrgAssignment.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8904 /*C_OrgAssignment.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3866 /*C_Payment.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3868 /*C_Payment.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14324 /*C_PaymentAllocate.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14326 /*C_PaymentAllocate.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5309 /*C_PaymentBatch.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5311 /*C_PaymentBatch.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5167 /*C_PaymentProcessor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5169 /*C_PaymentProcessor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2032 /*C_PaymentTerm.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2034 /*C_PaymentTerm.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3171 /*C_PaymentTerm_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3173 /*C_PaymentTerm_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200744 /*C_PaymentTransaction.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200800 /*C_PaymentTransaction.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8413 /*C_Payment_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8363 /*C_Payment_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8255 /*C_PaySchedule.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8256 /*C_PaySchedule.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5614 /*C_PaySelection.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5616 /*C_PaySelection.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7673 /*C_PaySelectionCheck.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7671 /*C_PaySelectionCheck.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206646 /*C_PaySelection_Check_v.AD_OrgInfo_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206659 /*C_PaySelection_Check_v.AD_OrgInfo_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206592 /*C_PaySelection_Check_v.C_BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206636 /*C_PaySelection_Check_v.C_BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206534 /*C_PaySelection_Check_v.C_Payment_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206575 /*C_PaySelection_Check_v.C_Payment_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206491 /*C_PaySelection_Check_v.C_PaySelectionCheck_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206499 /*C_PaySelection_Check_v.C_PaySelectionCheck_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206503 /*C_PaySelection_Check_v.C_PaySelection_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206511 /*C_PaySelection_Check_v.C_PaySelection_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5632 /*C_PaySelectionLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5634 /*C_PaySelectionLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204264 /*C_PaySelection_Remittance_v.C_Invoice_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204296 /*C_PaySelection_Remittance_v.C_Invoice_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204239 /*C_PaySelection_Remittance_v.C_PaySelectionLine_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204246 /*C_PaySelection_Remittance_v.C_PaySelectionLine_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=842 /*C_Period.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=844 /*C_Period.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1817 /*C_PeriodControl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1819 /*C_PeriodControl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8739 /*C_Phase.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8738 /*C_Phase.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12743 /*C_POS.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12741 /*C_POS.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12777 /*C_POSKey.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12775 /*C_POSKey.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12756 /*C_POSKeyLayout.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12766 /*C_POSKeyLayout.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200430 /*C_POSPayment.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200438 /*C_POSPayment.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200414 /*C_POSTenderType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200422 /*C_POSTenderType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1354 /*C_Project.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1357 /*C_Project.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2299 /*C_Project_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2301 /*C_Project_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206682 /*C_Project_Details_v.C_Project_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206709 /*C_Project_Details_v.C_Project_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9705 /*C_Project_Details_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206715 /*C_Project_Details_v.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206761 /*C_Project_Details_v.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9709 /*C_Project_Details_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206839 /*C_Project_Header_v.AD_OrgInfo_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206852 /*C_Project_Header_v.AD_OrgInfo_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206966 /*C_Project_Header_v.AD_User_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206976 /*C_Project_Header_v.AD_User_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206788 /*C_Project_Header_v.C_BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206986 /*C_Project_Header_v.C_BP_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206999 /*C_Project_Header_v.C_BP_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206833 /*C_Project_Header_v.C_BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9665 /*C_Project_Header_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206901 /*C_Project_Header_v.SalesRep_BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206951 /*C_Project_Header_v.SalesRep_BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206875 /*C_Project_Header_v.SalesRep_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9664 /*C_Project_Header_v.SalesRep_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206887 /*C_Project_Header_v.SalesRep_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9643 /*C_Project_Header_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9838 /*C_ProjectIssue.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9851 /*C_ProjectIssue.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13273 /*C_ProjectIssueMA.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13271 /*C_ProjectIssueMA.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5763 /*C_ProjectLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5765 /*C_ProjectLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8719 /*C_ProjectPhase.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8710 /*C_ProjectPhase.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8893 /*C_ProjectTask.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8895 /*C_ProjectTask.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8707 /*C_ProjectType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8704 /*C_ProjectType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8679 /*C_Recurring.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8694 /*C_Recurring.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211575 /*C_RecurringGroup.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211583 /*C_RecurringGroup.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8670 /*C_Recurring_Run.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8665 /*C_Recurring_Run.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=861 /*C_Region.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=863 /*C_Region.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211082 /*C_Region_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211085 /*C_Region_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13822 /*C_Remuneration.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13824 /*C_Remuneration.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3923 /*C_RevenueRecognition.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3925 /*C_RevenueRecognition.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5965 /*C_RevenueRecognition_Plan.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5967 /*C_RevenueRecognition_Plan.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5980 /*C_RevenueRecognition_Run.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5982 /*C_RevenueRecognition_Run.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=74652 /*C_RevenueRecog_Service.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=74659 /*C_RevenueRecog_Service.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11082 /*C_RfQ.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11095 /*C_RfQ.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11063 /*C_RfQLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11054 /*C_RfQLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11053 /*C_RfQLineQty.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11048 /*C_RfQLineQty.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11022 /*C_RfQResponse.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11015 /*C_RfQResponse.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11004 /*C_RfQResponseLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11012 /*C_RfQResponseLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10992 /*C_RfQResponseLineQty.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10990 /*C_RfQResponseLineQty.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12034 /*C_RfQResponseLineQty_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12030 /*C_RfQResponseLineQty_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11977 /*C_RfQResponseLine_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11980 /*C_RfQResponseLine_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12007 /*C_RfQResponse_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12008 /*C_RfQResponse_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10980 /*C_RfQ_Topic.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10984 /*C_RfQ_Topic.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10974 /*C_RfQ_TopicSubscriber.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10978 /*C_RfQ_TopicSubscriber.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12735 /*C_RfQ_TopicSubscriberOnly.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12730 /*C_RfQ_TopicSubscriberOnly.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62172 /*C_SalesDashboard.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62176 /*C_SalesDashboard.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1828 /*C_SalesRegion.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1830 /*C_SalesRegion.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211094 /*C_SalesRegion_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211097 /*C_SalesRegion_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62156 /*C_SalesStage.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62160 /*C_SalesStage.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211159 /*C_SalesStage_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211162 /*C_SalesStage_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3936 /*C_ServiceLevel.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3938 /*C_ServiceLevel.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3951 /*C_ServiceLevelLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3953 /*C_ServiceLevelLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14580 /*C_SubAcct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14582 /*C_SubAcct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10953 /*C_Subscription.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10961 /*C_Subscription.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10933 /*C_Subscription_Delivery.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10931 /*C_Subscription_Delivery.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10939 /*C_SubscriptionType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10944 /*C_SubscriptionType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8874 /*C_Task.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8877 /*C_Task.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2245 /*C_Tax.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2277 /*C_Tax.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5081 /*C_Tax_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5083 /*C_Tax_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54454 /*C_TaxBase.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54460 /*C_TaxBase.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2071 /*C_TaxCategory.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2073 /*C_TaxCategory.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4100 /*C_TaxCategory_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4102 /*C_TaxCategory_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14456 /*C_TaxDeclaration.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14458 /*C_TaxDeclaration.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14490 /*C_TaxDeclarationAcct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14492 /*C_TaxDeclarationAcct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14471 /*C_TaxDeclarationLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14473 /*C_TaxDeclarationLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54421 /*C_TaxDefinition.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54432 /*C_TaxDefinition.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54400 /*C_TaxGroup.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54405 /*C_TaxGroup.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11459 /*C_TaxPostal.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11460 /*C_TaxPostal.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210711 /*C_TaxProvider.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210717 /*C_TaxProvider.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210696 /*C_TaxProviderCfg.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210702 /*C_TaxProviderCfg.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8207 /*C_Tax_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8200 /*C_Tax_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54441 /*C_TaxType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54446 /*C_TaxType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=852 /*C_UOM.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=854 /*C_UOM.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1007 /*C_UOM_Conversion.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1009 /*C_UOM_Conversion.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3964 /*C_UOM_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3966 /*C_UOM_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13850 /*C_UserRemuneration.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13852 /*C_UserRemuneration.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1000016 /*CUST_Detail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1000024 /*CUST_Detail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1000003 /*CUST_Master.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1000011 /*CUST_Master.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1019 /*C_ValidCombination.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1021 /*C_ValidCombination.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3182 /*C_Withholding.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3184 /*C_Withholding.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5095 /*C_Withholding_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5097 /*C_Withholding_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1035 /*C_Year.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1037 /*C_Year.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54277 /*DD_NetworkDistribution.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54279 /*DD_NetworkDistribution.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54295 /*DD_NetworkDistributionLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54303 /*DD_NetworkDistributionLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53882 /*DD_Order.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53920 /*DD_Order.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56194 /*DD_Order_Header_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56196 /*DD_Order_Header_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53936 /*DD_OrderLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53959 /*DD_OrderLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54492 /*EXP_Format.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54494 /*EXP_Format.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54508 /*EXP_FormatLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54510 /*EXP_FormatLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54530 /*EXP_Processor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54532 /*EXP_Processor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54547 /*EXP_ProcessorParameter.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54549 /*EXP_ProcessorParameter.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54560 /*EXP_Processor_Type.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54562 /*EXP_Processor_Type.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5852 /*Fact_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5854 /*Fact_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9421 /*Fact_Acct_Balance.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9422 /*Fact_Acct_Balance.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57605 /*Fact_Acct_Summary.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57607 /*Fact_Acct_Summary.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59771 /*Fact_Reconciliation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59765 /*Fact_Reconciliation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2543 /*GL_Budget.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2545 /*GL_Budget.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14535 /*GL_BudgetControl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14537 /*GL_BudgetControl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1535 /*GL_Category.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1537 /*GL_Category.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210992 /*GL_Category_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210995 /*GL_Category_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11668 /*GL_Distribution.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11667 /*GL_Distribution.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11634 /*GL_DistributionLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11635 /*GL_DistributionLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14551 /*GL_Fund.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14553 /*GL_Fund.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14566 /*GL_FundRestriction.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14568 /*GL_FundRestriction.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1622 /*GL_Journal.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1624 /*GL_Journal.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1646 /*GL_JournalBatch.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1648 /*GL_JournalBatch.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200498 /*GL_JournalGenerator.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200504 /*GL_JournalGenerator.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200516 /*GL_JournalGeneratorLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200522 /*GL_JournalGeneratorLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200537 /*GL_JournalGeneratorSource.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200541 /*GL_JournalGeneratorSource.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1664 /*GL_JournalLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1666 /*GL_JournalLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54767 /*HR_Attribute.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54784 /*HR_Attribute.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54839 /*HR_Concept.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54832 /*HR_Concept.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54845 /*HR_Concept_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54852 /*HR_Concept_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54959 /*HR_Concept_Category.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54966 /*HR_Concept_Category.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54728 /*HR_Contract.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54734 /*HR_Contract.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54790 /*HR_Department.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54795 /*HR_Department.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54744 /*HR_Employee.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54758 /*HR_Employee.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54801 /*HR_Job.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54811 /*HR_Job.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54983 /*HR_List.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54993 /*HR_List.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55022 /*HR_ListLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55030 /*HR_ListLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54972 /*HR_ListType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54977 /*HR_ListType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55000 /*HR_ListVersion.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55007 /*HR_ListVersion.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55038 /*HR_Movement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55051 /*HR_Movement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54891 /*HR_Payroll.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54900 /*HR_Payroll.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54944 /*HR_PayrollConcept.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54955 /*HR_PayrollConcept.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54908 /*HR_Period.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54924 /*HR_Period.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54866 /*HR_Process.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54880 /*HR_Process.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54929 /*HR_Year.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54939 /*HR_Year.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56063 /*I_Asset.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56034 /*I_Asset.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9326 /*I_BankStatement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9291 /*I_BankStatement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7880 /*I_BPartner.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7879 /*I_BPartner.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10391 /*I_Conversion_Rate.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10403 /*I_Conversion_Rate.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7928 /*I_ElementValue.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7908 /*I_ElementValue.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55450 /*I_FAJournal.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55464 /*I_FAJournal.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59501 /*I_FixedAsset.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59503 /*I_FixedAsset.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9277 /*I_GLJournal.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9255 /*I_GLJournal.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58957 /*I_HR_Movement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58966 /*I_HR_Movement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12545 /*I_InOutLineConfirm.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12537 /*I_InOutLineConfirm.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8659 /*I_Inventory.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8651 /*I_Inventory.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9189 /*I_Invoice.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9221 /*I_Invoice.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59547 /*I_Movement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59544 /*I_Movement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54574 /*IMP_Processor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54576 /*IMP_Processor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54611 /*IMP_ProcessorLog.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54613 /*IMP_ProcessorLog.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54597 /*IMP_ProcessorParameter.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54599 /*IMP_ProcessorParameter.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54626 /*IMP_Processor_Type.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54628 /*IMP_Processor_Type.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9004 /*I_Order.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9019 /*I_Order.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9132 /*I_Payment.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9140 /*I_Payment.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56939 /*I_PriceList.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56977 /*I_PriceList.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7838 /*I_Product.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7821 /*I_Product.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58981 /*I_ProductPlanning.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59016 /*I_ProductPlanning.SalesRep_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58984 /*I_ProductPlanning.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7961 /*I_ReportLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7944 /*I_ReportLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8515 /*M_Attribute.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8514 /*M_Attribute.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8502 /*M_AttributeInstance.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8524 /*M_AttributeInstance.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8544 /*M_AttributeSearch.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8540 /*M_AttributeSearch.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8495 /*M_AttributeSet.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8496 /*M_AttributeSet.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14291 /*M_AttributeSetExclude.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14293 /*M_AttributeSetExclude.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8478 /*M_AttributeSetInstance.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8480 /*M_AttributeSetInstance.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8528 /*M_AttributeUse.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8533 /*M_AttributeUse.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8461 /*M_AttributeValue.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8462 /*M_AttributeValue.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13913 /*M_BOM.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13915 /*M_BOM.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13870 /*M_BOMAlternative.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13872 /*M_BOMAlternative.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13958 /*M_BOMProduct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13960 /*M_BOMProduct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61830 /*M_BP_Price.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61839 /*M_BP_Price.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13929 /*M_ChangeNotice.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13931 /*M_ChangeNotice.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13942 /*M_ChangeRequest.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13944 /*M_ChangeRequest.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201223 /*M_CommodityShipment.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201232 /*M_CommodityShipment.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13475 /*M_Cost.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13477 /*M_Cost.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14179 /*M_CostDetail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14181 /*M_CostDetail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13457 /*M_CostElement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13459 /*M_CostElement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200023 /*M_CostHistory.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200040 /*M_CostHistory.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200071 /*M_CostMovement_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200073 /*M_CostMovement_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14417 /*M_CostQueue.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14419 /*M_CostQueue.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8915 /*M_CostType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8925 /*M_CostType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11946 /*M_Demand.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11952 /*M_Demand.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11920 /*M_DemandDetail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11923 /*M_DemandDetail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11903 /*M_DemandLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11901 /*M_DemandLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6586 /*M_DiscountSchema.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6588 /*M_DiscountSchema.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6603 /*M_DiscountSchemaBreak.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6605 /*M_DiscountSchemaBreak.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6617 /*M_DiscountSchemaLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6619 /*M_DiscountSchemaLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10903 /*M_DistributionList.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10904 /*M_DistributionList.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10899 /*M_DistributionListLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10893 /*M_DistributionListLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11779 /*M_DistributionRun.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11780 /*M_DistributionRun.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11798 /*M_DistributionRunLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11797 /*M_DistributionRunLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11906 /*M_Forecast.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11904 /*M_Forecast.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11936 /*M_ForecastLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56113 /*M_ForecastLine.SalesRep_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11933 /*M_ForecastLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9098 /*M_Freight.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9100 /*M_Freight.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9084 /*M_FreightCategory.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9089 /*M_FreightCategory.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3526 /*M_InOut.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3528 /*M_InOut.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12085 /*M_InOutConfirm.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12094 /*M_InOutConfirm.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12270 /*M_InOutConfirm_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12251 /*M_InOutConfirm_v.SalesRep_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12256 /*M_InOutConfirm_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207186 /*M_InOut_Header_v.AD_OrgInfo_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207199 /*M_InOut_Header_v.AD_OrgInfo_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207166 /*M_InOut_Header_v.AD_User_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207176 /*M_InOut_Header_v.AD_User_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207075 /*M_InOut_Header_v.C_BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207129 /*M_InOut_Header_v.C_BP_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207142 /*M_InOut_Header_v.C_BP_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207120 /*M_InOut_Header_v.C_BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207152 /*M_InOut_Header_v.C_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207157 /*M_InOut_Header_v.C_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7193 /*M_InOut_Header_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207039 /*M_InOut_Header_v.DropShip_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7183 /*M_InOut_Header_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3534 /*M_InOutLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3536 /*M_InOutLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12107 /*M_InOutLineConfirm.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12105 /*M_InOutLineConfirm.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12206 /*M_InOut_LineConfirm_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12237 /*M_InOut_LineConfirm_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13328 /*M_InOutLineMA.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13330 /*M_InOutLineMA.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14367 /*M_InOutLineMA_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14369 /*M_InOutLineMA_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207317 /*M_InOut_Line_v.C_OrderLine_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207352 /*M_InOut_Line_v.C_OrderLine_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7222 /*M_InOut_Line_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207295 /*M_InOut_Line_v.M_ASI_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207299 /*M_InOut_Line_v.M_ASI_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207236 /*M_InOut_Line_v.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207280 /*M_InOut_Line_v.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7214 /*M_InOut_Line_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3547 /*M_Inventory.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3549 /*M_Inventory.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3560 /*M_InventoryLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3562 /*M_InventoryLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13360 /*M_InventoryLineMA.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13362 /*M_InventoryLineMA.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1394 /*M_Locator.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1396 /*M_Locator.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212184 /*M_LocatorType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212192 /*M_LocatorType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8457 /*M_Lot.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8449 /*M_Lot.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8432 /*M_LotCtl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8434 /*M_LotCtl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14302 /*M_LotCtlExclude.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14304 /*M_LotCtlExclude.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6502 /*M_MatchInv.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6504 /*M_MatchInv.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6518 /*M_MatchPO.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6520 /*M_MatchPO.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3574 /*M_Movement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3575 /*M_Movement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12447 /*M_MovementConfirm.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12443 /*M_MovementConfirm.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3587 /*M_MovementLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3589 /*M_MovementLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12419 /*M_MovementLineConfirm.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12429 /*M_MovementLineConfirm.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13308 /*M_MovementLineMA.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13310 /*M_MovementLineMA.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14381 /*M_MovementLineMA_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14383 /*M_MovementLineMA_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13896 /*M_OperationResource.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13898 /*M_OperationResource.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10880 /*M_Package.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10881 /*M_Package.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10867 /*M_PackageLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10872 /*M_PackageLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201187 /*M_PackageMPS.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201196 /*M_PackageMPS.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61989 /*M_PartType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61992 /*M_PartType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4003 /*M_PerpetualInv.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4005 /*M_PerpetualInv.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2105 /*M_PriceList.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2107 /*M_PriceList.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211107 /*M_PriceList_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211110 /*M_PriceList_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2992 /*M_PriceList_Version.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2994 /*M_PriceList_Version.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211120 /*M_PriceList_Version_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211123 /*M_PriceList_Version_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1407 /*M_Product.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1409 /*M_Product.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2562 /*M_Product_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2564 /*M_Product_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4718 /*M_Product_BOM.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4720 /*M_Product_BOM.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1773 /*M_Product_Category.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1775 /*M_Product_Category.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5116 /*M_Product_Category_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5118 /*M_Product_Category_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211004 /*M_Product_Category_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211007 /*M_Product_Category_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13593 /*M_ProductDownload.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13595 /*M_ProductDownload.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3601 /*M_Production.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3603 /*M_Production.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3616 /*M_ProductionLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3618 /*M_ProductionLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13282 /*M_ProductionLineMA.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13280 /*M_ProductionLineMA.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4759 /*M_ProductionPlan.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4761 /*M_ProductionPlan.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13881 /*M_ProductOperation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13883 /*M_ProductOperation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2314 /*M_Product_PO.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2316 /*M_Product_PO.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2060 /*M_ProductPrice.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2062 /*M_ProductPrice.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56919 /*M_ProductPriceVendorBreak.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56927 /*M_ProductPriceVendorBreak.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61978 /*M_Product_QualityTest.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61981 /*M_Product_QualityTest.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3327 /*M_Product_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3329 /*M_Product_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57054 /*M_Promotion.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57060 /*M_Promotion.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57096 /*M_PromotionDistribution.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57100 /*M_PromotionDistribution.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57033 /*M_PromotionGroup.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57039 /*M_PromotionGroup.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57043 /*M_PromotionGroupLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57048 /*M_PromotionGroupLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57065 /*M_PromotionLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57069 /*M_PromotionLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57077 /*M_PromotionPreCondition.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57081 /*M_PromotionPreCondition.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57110 /*M_PromotionReward.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57114 /*M_PromotionReward.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61967 /*M_QualityTest.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61972 /*M_QualityTest.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61952 /*M_QualityTestResult.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61955 /*M_QualityTestResult.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10858 /*M_RelatedProduct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10851 /*M_RelatedProduct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1963 /*M_Replenish.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1965 /*M_Replenish.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11488 /*M_Requisition.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11481 /*M_Requisition.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11502 /*M_RequisitionLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11496 /*M_RequisitionLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10844 /*M_RMA.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10840 /*M_RMA.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10828 /*M_RMALine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10830 /*M_RMALine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208389 /*M_RMATax.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208396 /*M_RMATax.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12139 /*M_RMAType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12135 /*M_RMAType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8523 /*M_SerNoCtl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8419 /*M_SerNoCtl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14313 /*M_SerNoCtlExclude.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14315 /*M_SerNoCtlExclude.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2082 /*M_Shipper.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2084 /*M_Shipper.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202077 /*M_ShipperCfg.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202091 /*M_ShipperCfg.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201090 /*M_ShipperLabels.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201101 /*M_ShipperLabels.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202096 /*M_ShipperLabelsCfg.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202107 /*M_ShipperLabelsCfg.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201111 /*M_ShipperPackaging.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201122 /*M_ShipperPackaging.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202113 /*M_ShipperPackagingCfg.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202122 /*M_ShipperPackagingCfg.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201128 /*M_ShipperPickupTypes.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201137 /*M_ShipperPickupTypes.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202128 /*M_ShipperPickupTypesCfg.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202137 /*M_ShipperPickupTypesCfg.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201015 /*M_ShippingProcessor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201023 /*M_ShippingProcessor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202056 /*M_ShippingProcessorCfg.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202071 /*M_ShippingProcessorCfg.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202160 /*M_ShippingTransaction.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202224 /*M_ShippingTransaction.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202296 /*M_ShippingTransactionLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202312 /*M_ShippingTransactionLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1976 /*M_Storage.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1978 /*M_Storage.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200617 /*M_StorageOnHand.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200627 /*M_StorageOnHand.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200631 /*M_StorageReservation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200639 /*M_StorageReservation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1440 /*M_Substitute.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1442 /*M_Substitute.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3663 /*M_Transaction.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3665 /*M_Transaction.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10237 /*M_TransactionAllocation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10255 /*M_TransactionAllocation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13347 /*M_Transaction_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13349 /*M_Transaction_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1251 /*M_Warehouse.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1253 /*M_Warehouse.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2447 /*M_Warehouse_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2449 /*M_Warehouse_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5861 /*PA_Achievement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5863 /*PA_Achievement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14793 /*PA_Benchmark.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14795 /*PA_Benchmark.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14805 /*PA_BenchmarkData.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14807 /*PA_BenchmarkData.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14742 /*PA_ColorSchema.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14744 /*PA_ColorSchema.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=51009 /*PA_DashboardContent.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=51011 /*PA_DashboardContent.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210857 /*PA_DashboardContent_Access.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210859 /*PA_DashboardContent_Access.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60121 /*PA_DashboardContent_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60128 /*PA_DashboardContent_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200332 /*PA_DashboardPreference.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200348 /*PA_DashboardPreference.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212990 /*PA_DocumentStatus.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=212992 /*PA_DocumentStatus.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213014 /*PA_DocumentStatus_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213019 /*PA_DocumentStatus_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5889 /*PA_Goal.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5891 /*PA_Goal.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14768 /*PA_GoalRestriction.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14770 /*PA_GoalRestriction.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14513 /*PA_Hierarchy.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14515 /*PA_Hierarchy.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5917 /*PA_Measure.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5919 /*PA_Measure.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5932 /*PA_MeasureCalc.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5934 /*PA_MeasureCalc.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14818 /*PA_Ratio.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14820 /*PA_Ratio.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14830 /*PA_RatioElement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14832 /*PA_RatioElement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5991 /*PA_Report.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5993 /*PA_Report.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6004 /*PA_ReportColumn.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6006 /*PA_ReportColumn.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6039 /*PA_ReportColumnSet.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6041 /*PA_ReportColumnSet.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=214006 /*PA_ReportColumn_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=214008 /*PA_ReportColumn_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57560 /*PA_ReportCube.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57565 /*PA_ReportCube.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6050 /*PA_ReportLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6052 /*PA_ReportLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6071 /*PA_ReportLineSet.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6073 /*PA_ReportLineSet.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213993 /*PA_ReportLine_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213995 /*PA_ReportLine_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6080 /*PA_ReportSource.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6082 /*PA_ReportSource.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12682 /*PA_SLA_Criteria.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12681 /*PA_SLA_Criteria.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12695 /*PA_SLA_Goal.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12705 /*PA_SLA_Goal.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12679 /*PA_SLA_Measure.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12678 /*PA_SLA_Measure.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53814 /*PP_Cost_Collector.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53841 /*PP_Cost_Collector.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54314 /*PP_Cost_CollectorMA.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54321 /*PP_Cost_CollectorMA.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54029 /*PP_MRP.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54057 /*PP_MRP.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53635 /*PP_Order.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53677 /*PP_Order.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53603 /*PP_Order_BOM.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53616 /*PP_Order_BOM.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57330 /*PP_Order_BOM_Header_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57332 /*PP_Order_BOM_Header_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53561 /*PP_Order_BOMLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53589 /*PP_Order_BOMLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57260 /*PP_Order_BOMLine_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57267 /*PP_Order_BOMLine_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57392 /*PP_Order_BOMLine_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57394 /*PP_Order_BOMLine_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57247 /*PP_Order_BOM_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57255 /*PP_Order_BOM_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53537 /*PP_Order_Cost.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53553 /*PP_Order_Cost.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58121 /*PP_Order_Header_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58123 /*PP_Order_Header_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53463 /*PP_Order_Node.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53503 /*PP_Order_Node.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53745 /*PP_Order_Node_Asset.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53752 /*PP_Order_Node_Asset.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53518 /*PP_Order_NodeNext.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53530 /*PP_Order_NodeNext.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53731 /*PP_Order_Node_Product.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53739 /*PP_Order_Node_Product.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57206 /*PP_Order_Node_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57213 /*PP_Order_Node_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57504 /*PP_Order_Node_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57506 /*PP_Order_Node_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53696 /*PP_Order_Workflow.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53718 /*PP_Order_Workflow.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57433 /*PP_Order_Workflow_Header_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57435 /*PP_Order_Workflow_Header_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57193 /*PP_Order_Workflow_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57200 /*PP_Order_Workflow_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53328 /*PP_Product_BOM.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53337 /*PP_Product_BOM.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53352 /*PP_Product_BOMLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53371 /*PP_Product_BOMLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57234 /*PP_Product_BOMLine_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57242 /*PP_Product_BOMLine_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57218 /*PP_Product_BOM_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57226 /*PP_Product_BOM_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53379 /*PP_Product_Planning.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53404 /*PP_Product_Planning.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53297 /*PP_WF_Node_Asset.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53302 /*PP_WF_Node_Asset.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53282 /*PP_WF_Node_Product.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53290 /*PP_WF_Node_Product.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53989 /*QM_Specification.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13523 /*R_Category.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13521 /*R_Category.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13737 /*R_CategoryUpdates.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13739 /*R_CategoryUpdates.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7762 /*R_ContactInterest.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7763 /*R_ContactInterest.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13556 /*R_Group.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13558 /*R_Group.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13747 /*R_GroupUpdates.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13749 /*R_GroupUpdates.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7786 /*R_InterestArea.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7780 /*R_InterestArea.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14892 /*R_IssueKnown.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14894 /*R_IssueKnown.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14951 /*R_IssueProject.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14953 /*R_IssueProject.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14871 /*R_IssueRecommendation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14873 /*R_IssueRecommendation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14882 /*R_IssueStatus.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14884 /*R_IssueStatus.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14966 /*R_IssueSystem.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14968 /*R_IssueSystem.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14940 /*R_IssueUser.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14942 /*R_IssueUser.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5408 /*R_MailText.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5410 /*R_MailText.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14609 /*R_MailText_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14611 /*R_MailText_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5420 /*R_Request.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5422 /*R_Request.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5491 /*R_RequestAction.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5493 /*R_RequestAction.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5473 /*R_RequestProcessor.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5475 /*R_RequestProcessor.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10822 /*R_RequestProcessorLog.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10823 /*R_RequestProcessorLog.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6549 /*R_RequestProcessor_Route.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6551 /*R_RequestProcessor_Route.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7770 /*R_RequestType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7773 /*R_RequestType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13727 /*R_RequestTypeUpdates.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13729 /*R_RequestTypeUpdates.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13983 /*R_RequestUpdate.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13985 /*R_RequestUpdate.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13717 /*R_RequestUpdates.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13719 /*R_RequestUpdates.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13545 /*R_Resolution.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13547 /*R_Resolution.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13534 /*R_StandardResponse.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13532 /*R_StandardResponse.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13567 /*R_Status.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13569 /*R_Status.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14994 /*R_StatusCategory.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14996 /*R_StatusCategory.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204617 /*RV_Allocation.C_AllocationLine_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204622 /*RV_Allocation.C_AllocationLine_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12389 /*RV_Allocation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12380 /*RV_Allocation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9817 /*RV_Asset_Customer.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9807 /*RV_Asset_Customer.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9776 /*RV_Asset_Delivery.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9794 /*RV_Asset_Delivery.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11840 /*RV_Asset_SumMonth.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11850 /*RV_Asset_SumMonth.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207392 /*RV_BPartner.AD_User_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207395 /*RV_BPartner.AD_User_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207374 /*RV_BPartner.C_BP_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207387 /*RV_BPartner.C_BP_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207402 /*RV_BPartner.C_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207406 /*RV_BPartner.C_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14210 /*RV_BPartner.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14263 /*RV_BPartner.Supervisor_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14212 /*RV_BPartner.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13191 /*RV_BPartnerOpen.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13193 /*RV_BPartnerOpen.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6458 /*RV_Cash_Detail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6460 /*RV_Cash_Detail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207447 /*RV_C_Invoice.C_BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207505 /*RV_C_Invoice.C_BP_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207518 /*RV_C_Invoice.C_BP_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207498 /*RV_C_Invoice.C_BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207526 /*RV_C_Invoice.C_Location_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207531 /*RV_C_Invoice.C_Location_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5527 /*RV_C_Invoice.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5529 /*RV_C_Invoice.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14703 /*RV_C_InvoiceLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205540 /*RV_C_InvoiceLine.M_ASI_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205539 /*RV_C_InvoiceLine.M_ASI_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204699 /*RV_C_InvoiceLine.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204745 /*RV_C_InvoiceLine.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14705 /*RV_C_InvoiceLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207594 /*RV_C_InvoiceTax.C_BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207642 /*RV_C_InvoiceTax.C_BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207550 /*RV_C_InvoiceTax.C_Invoice_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207579 /*RV_C_InvoiceTax.C_Invoice_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10635 /*RV_C_InvoiceTax.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10646 /*RV_C_InvoiceTax.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10208 /*RV_Click_Unprocessed.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10197 /*RV_Click_Unprocessed.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204884 /*RV_CommissionRunDetail.Bill_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204761 /*RV_CommissionRunDetail.C_Commission_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204781 /*RV_CommissionRunDetail.C_CommissionDetail_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204784 /*RV_CommissionRunDetail.C_CommissionDetail_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204771 /*RV_CommissionRunDetail.C_Commission_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204775 /*RV_CommissionRunDetail.C_CommmissionAmt_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204778 /*RV_CommissionRunDetail.C_CommssionAmt_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204968 /*RV_CommissionRunDetail.C_Invoice_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204848 /*RV_CommissionRunDetail.C_InvoiceLine_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204874 /*RV_CommissionRunDetail.C_InvoiceLine_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205002 /*RV_CommissionRunDetail.C_Invoice_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204879 /*RV_CommissionRunDetail.C_Order_AD_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204901 /*RV_CommissionRunDetail.C_Order_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204798 /*RV_CommissionRunDetail.C_OrderLine_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204833 /*RV_CommissionRunDetail.C_OrderLine_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13232 /*RV_CommissionRunDetail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204913 /*RV_CommissionRunDetail.DropShip_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13230 /*RV_CommissionRunDetail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14107 /*RV_Cost.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205014 /*RV_Cost.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205059 /*RV_Cost.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14109 /*RV_Cost.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14150 /*RV_CostDetail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207718 /*RV_CostDetail.M_ASI_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207724 /*RV_CostDetail.M_ASI_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207664 /*RV_CostDetail.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207709 /*RV_CostDetail.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14152 /*RV_CostDetail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14130 /*RV_CostSummary.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14132 /*RV_CostSummary.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56253 /*RV_DD_OrderDetail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56255 /*RV_DD_OrderDetail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207753 /*RV_Fact_Acct.C_BP_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207803 /*RV_Fact_Acct.C_BP_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10737 /*RV_Fact_Acct.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207809 /*RV_Fact_Acct.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207855 /*RV_Fact_Acct.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10751 /*RV_Fact_Acct.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208744 /*RV_Fact_Simple.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208746 /*RV_Fact_Simple.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12160 /*RV_InOutConfirm.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12163 /*RV_InOutConfirm.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12845 /*RV_InOutDetails.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207869 /*RV_InOutDetails.DropShip_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207907 /*RV_InOutDetails.M_ASI_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207911 /*RV_InOutDetails.M_ASI_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207864 /*RV_InOutDetails.M_InOut_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207882 /*RV_InOutDetails.M_InOut_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12828 /*RV_InOutDetails.SalesRep_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12816 /*RV_InOutDetails.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12196 /*RV_InOutLineConfirm.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12192 /*RV_InOutLineConfirm.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11749 /*RV_M_Requisition.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11740 /*RV_M_Requisition.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207927 /*RV_M_Transaction.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207983 /*RV_M_Transaction.M_Product_PO_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208001 /*RV_M_Transaction.M_Product_PO_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207975 /*RV_M_Transaction.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207914 /*RV_M_Transaction.M_Transaction_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207922 /*RV_M_Transaction.M_Transation_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205245 /*RV_OpenItem.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205275 /*RV_OpenItem.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208024 /*RV_OrderDetail.C_Order_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208068 /*RV_OrderDetail.C_Order_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11610 /*RV_OrderDetail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208035 /*RV_OrderDetail.DropShip_User_ID->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208100 /*RV_OrderDetail.M_ASI_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208104 /*RV_OrderDetail.M_ASI_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11587 /*RV_OrderDetail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13100 /*RV_Payment.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13098 /*RV_Payment.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53418 /*RV_PP_MRP.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53442 /*RV_PP_MRP.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53848 /*RV_PP_Operation_Activity.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53862 /*RV_PP_Operation_Activity.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56091 /*RV_PP_Order_BOMLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56092 /*RV_PP_Order_BOMLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53757 /*RV_PP_Order_Storage.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53776 /*RV_PP_Order_Storage.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53785 /*RV_PP_Order_Transactions.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53801 /*RV_PP_Order_Transactions.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56486 /*RV_PP_Order_Workflow.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56489 /*RV_PP_Order_Workflow.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54328 /*RV_PP_Product_BOMLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54346 /*RV_PP_Product_BOMLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12512 /*RV_PrintFormatDetail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12496 /*RV_PrintFormatDetail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9761 /*RV_ProjectCycle.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9734 /*RV_ProjectCycle.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9984 /*RV_ProjectLineIssue.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9996 /*RV_ProjectLineIssue.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13755 /*RV_RequestUpdates.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13757 /*RV_RequestUpdates.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13768 /*RV_RequestUpdates_Only.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13770 /*RV_RequestUpdates_Only.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208161 /*RV_Storage.M_ASI_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208165 /*RV_Storage.M_ASI_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208116 /*RV_Storage.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208158 /*RV_Storage.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208107 /*RV_Storage.M_Storage_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208651 /*RV_T_1099Extract.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208653 /*RV_T_1099Extract.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208324 /*RV_Transaction.C_PrjctIssue_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208339 /*RV_Transaction.C_PrjctIssue_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208273 /*RV_Transaction.M_InOutLine_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208293 /*RV_Transaction.M_InOutLine_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208228 /*RV_Transaction.M_InventoryLine_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208242 /*RV_Transaction.M_InventoryLine_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208246 /*RV_Transaction.M_MovementLine_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208261 /*RV_Transaction.M_MovementLine_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208180 /*RV_Transaction.M_Product_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208298 /*RV_Transaction.M_ProductionLine_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208308 /*RV_Transaction.M_ProductionLine_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208311 /*RV_Transaction.M_ProductionPlan_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208320 /*RV_Transaction.M_ProductionPlan_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208224 /*RV_Transaction.M_Product_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208167 /*RV_Transaction.M_Transaction_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208171 /*RV_Transaction.M_Transction_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12337 /*RV_UnPosted.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12344 /*RV_UnPosted.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57927 /*RV_Unprocessed.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57924 /*RV_Unprocessed.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10301 /*RV_WarehousePrice.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10316 /*RV_WarehousePrice.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6908 /*S_ExpenseType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6910 /*S_ExpenseType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6857 /*S_Resource.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6855 /*S_Resource.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6829 /*S_ResourceAssignment.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6827 /*S_ResourceAssignment.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6894 /*S_ResourceType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6896 /*S_ResourceType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6783 /*S_ResourceUnAvailable.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6781 /*S_ResourceUnAvailable.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6843 /*S_TimeExpense.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6841 /*S_TimeExpense.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6883 /*S_TimeExpenseLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6881 /*S_TimeExpenseLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8848 /*S_TimeType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8847 /*S_TimeType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8026 /*S_Training.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8025 /*S_Training.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8011 /*S_Training_Class.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8013 /*S_Training_Class.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208616 /*T_1099Extract.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208622 /*T_1099Extract.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10155 /*T_Aging.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10157 /*T_Aging.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62011 /*T_BOM_Indented.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62024 /*T_BOM_Indented.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54076 /*T_BOMLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54086 /*T_BOMLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56635 /*T_BOMLine_Costs.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56636 /*T_BOMLine_Costs.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60224 /*T_CashFlow.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60235 /*T_CashFlow.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11806 /*T_DistributionRunDetail.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11807 /*T_DistributionRunDetail.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=765 /*Test.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=766 /*Test.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14070 /*T_InvoiceGL.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14072 /*T_InvoiceGL.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14012 /*T_InvoiceGL_v.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205524 /*T_InvoiceGL_v.Fact_Acct_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205473 /*T_InvoiceGL_v.T_InvoiceGL_CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205477 /*T_InvoiceGL_v.T_InvoiceGL_UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14010 /*T_InvoiceGL_v.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54065 /*T_MRP_CRP.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54071 /*T_MRP_CRP.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59782 /*T_Reconciliation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59787 /*T_Reconciliation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54678 /*T_Replenish.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59711 /*T_RV_Reconciliation.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59728 /*T_RV_Reconciliation.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13264 /*T_Transaction.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13266 /*T_Transaction.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13000 /*T_TrialBalance.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12998 /*T_TrialBalance.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52016 /*U_BlackListCheque.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52018 /*U_BlackListCheque.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52093 /*U_POSTerminal.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52109 /*U_POSTerminal.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52036 /*U_RoleMenu.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52038 /*U_RoleMenu.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52046 /*U_WebMenu.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52048 /*U_WebMenu.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52026 /*U_Web_Properties.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52028 /*U_Web_Properties.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8784 /*W_Advertisement.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8801 /*W_Advertisement.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8346 /*W_Basket.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8344 /*W_Basket.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8277 /*W_BasketLine.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8273 /*W_BasketLine.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8290 /*W_Click.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8291 /*W_Click.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8339 /*W_ClickCount.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8342 /*W_ClickCount.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6105 /*W_Counter.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6101 /*W_Counter.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8318 /*W_CounterCount.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8320 /*W_CounterCount.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13664 /*W_MailMsg.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13666 /*W_MailMsg.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13681 /*W_MailMsg_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13683 /*W_MailMsg_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13610 /*W_Store.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13612 /*W_Store.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13646 /*W_Store_Trl.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13648 /*W_Store_Trl.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56697 /*WS_WebService.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56704 /*WS_WebService.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56751 /*WS_WebServiceFieldInput.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56754 /*WS_WebServiceFieldInput.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56760 /*WS_WebServiceFieldOutput.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56763 /*WS_WebServiceFieldOutput.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56709 /*WS_WebServiceMethod.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56716 /*WS_WebServiceMethod.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56739 /*WS_WebService_Para.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56742 /*WS_WebService_Para.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56722 /*WS_WebServiceType.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56729 /*WS_WebServiceType.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56771 /*WS_WebServiceTypeAccess.CreatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56775 /*WS_WebServiceTypeAccess.UpdatedBy->AD_User*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10807 /*AD_Note.AD_WF_Activity_ID->AD_WF_Activity*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=213232 /*AD_WF_ActivityApprover.AD_WF_Activity_ID->AD_WF_Activity*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10525 /*AD_WF_ActivityResult.AD_WF_Activity_ID->AD_WF_Activity*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10445 /*AD_WF_Activity.AD_WF_Process_ID->AD_WF_Process*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11679 /*AD_WF_EventAudit.AD_WF_Process_ID->AD_WF_Process*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10470 /*AD_WF_Process.AD_WF_Process_ID->AD_WF_Process*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10496 /*AD_WF_ProcessData.AD_WF_Process_ID->AD_WF_Process*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11226 /*B_Bid.B_BuyerFunds_ID->B_BuyerFunds*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11179 /*B_Offer.B_SellerFunds_ID->B_SellerFunds*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11222 /*B_Bid.B_Topic_ID->B_Topic*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11209 /*B_BidComment.B_Topic_ID->B_Topic*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11169 /*B_Offer.B_Topic_ID->B_Topic*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200882 /*C_AllocationHdr.Reversal_ID->C_AllocationHdr*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4874 /*C_AllocationLine.C_AllocationHdr_ID->C_AllocationHdr*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14096 /*A_Asset.C_BPartnerSR_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55880 /*A_Asset_Change.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2756 /*C_BP_Customer_Acct.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2757 /*C_BP_Employee_Acct.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2758 /*C_BP_Vendor_Acct.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210163 /*C_Dunning_Header_v.AD_User_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201289 /*C_Dunning_Header_v.C_BPartner_BPartner_Parent_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201447 /*C_Dunning_Header_v.SalesRep_BPartner_BP_Parent_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201425 /*C_Dunning_Header_v.SalesRep_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201513 /*C_Dunning_Line_v.C_Invoice_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201576 /*C_Dunning_Line_v.C_Payment_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203589 /*C_Invoice_Header_v.AD_User_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203654 /*C_Invoice_Header_v.BPartner_BPartner_Parent_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210217 /*C_Invoice_Header_v.BP_BPartner_Parent_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203555 /*C_Invoice_Header_v.BP_Location_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203630 /*C_Invoice_Header_v.SalesRep_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205709 /*C_Invoice_LineTax_v.C_BP_Product_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205699 /*C_Invoice_LineTax_v.C_Charge_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205572 /*C_Invoice_LineTax_v.C_Invoice_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8764 /*C_Order.Bill_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205915 /*C_Order_Header_v.AD_User_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11964 /*C_Order_Header_v.Bill_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206297 /*C_Order_Header_v.Bill_BP_Location_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206316 /*C_Order_Header_v.Bill_User_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210226 /*C_Order_Header_v.BP_BPartner_Parent_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205881 /*C_Order_Header_v.BP_Location_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205757 /*C_Order_Header_v.DropShip_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205776 /*C_Order_Header_v.Pay_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206150 /*C_Order_Header_v.SalesRep_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203841 /*C_Order_LineTax_v.Bill_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204038 /*C_Order_LineTax_v.BPartner_Parent_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204020 /*C_Order_LineTax_v.C_BP_Product_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204010 /*C_Order_LineTax_v.C_Charge_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203845 /*C_Order_LineTax_v.C_Order_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203970 /*C_Order_LineTax_v.M_Product_PO_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203898 /*C_Order_LineTax_v.Pay_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206522 /*C_PaySelection_Check_v.C_Payment_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14095 /*C_Project.C_BPartnerSR_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206670 /*C_Project_Details_v.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206672 /*C_Project_Details_v.C_BPartnerSR_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206961 /*C_Project_Header_v.AD_User_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206984 /*C_Project_Header_v.C_BP_Location_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206870 /*C_Project_Header_v.SalesRep_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3191 /*C_Withholding.Beneficiary->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56203 /*DD_Order_Header_v.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57591 /*Fact_Acct_Summary.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54764 /*HR_Attribute.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54742 /*HR_Employee.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55034 /*HR_Movement.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54884 /*HR_Process.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59564 /*I_Movement.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207161 /*M_InOut_Header_v.AD_User_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207127 /*M_InOut_Header_v.C_BP_Location_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207037 /*M_InOut_Header_v.DropShip_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207356 /*M_InOut_Line_v.C_Charge_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207308 /*M_InOut_Line_v.C_OrderLine_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=61942 /*M_Production.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205531 /*M_ShippingTransaction.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202316 /*M_ShippingTransaction.ReturnBPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6028 /*PA_ReportColumn.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6089 /*PA_ReportSource.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57508 /*PP_Order_Node_v.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207389 /*RV_BPartner.AD_User_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207371 /*RV_BPartner.C_BP_Location_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207502 /*RV_C_Invoice.C_BP_Location_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4809 /*RV_C_Invoice_CustomerVendQtr.Vendor_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204882 /*RV_CommissionRunDetail.Bill_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13222 /*RV_CommissionRunDetail.Commission_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204788 /*RV_CommissionRunDetail.C_OrderLine_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204911 /*RV_CommissionRunDetail.DropShip_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204938 /*RV_CommissionRunDetail.Pay_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56523 /*RV_DD_OrderDetail.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207867 /*RV_InOutDetails.DropShip_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208009 /*RV_OrderDetail.C_Order_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208033 /*RV_OrderDetail.DropShip_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13091 /*RV_Payment.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58803 /*RV_PP_MRP.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56508 /*RV_PP_Order_Workflow.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208654 /*RV_T_1099Extract.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6839 /*S_TimeExpense.C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208639 /*T_1099Extract.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208724 /*T_BankRegister.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14056 /*T_InvoiceGL_v.C_BPartner_ID->C_BPartner*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205512 /*T_InvoiceGL_v.Fact_Acct_C_BPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52084 /*U_POSTerminal.C_CashBPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=52094 /*U_POSTerminal.C_TemplateBPartner_ID->C_BPartner*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5835 /*C_CommissionDetail.C_CommissionAmt_ID->C_CommissionAmt*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13221 /*RV_CommissionRunDetail.C_CommissionAmt_ID->C_CommissionAmt*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13217 /*RV_CommissionRunDetail.C_CommissionDetail_ID->C_CommissionDetail*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5801 /*C_CommissionAmt.C_CommissionRun_ID->C_CommissionRun*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13229 /*RV_CommissionRunDetail.C_CommissionRun_ID->C_CommissionRun*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208443 /*C_Payment.C_DepositBatch_ID->C_DepositBatch*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9558 /*C_Cash.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9559 /*C_Cash.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60177 /*C_CashPlan.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60155 /*C_CashPlan.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60187 /*C_CashPlanLine.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=60188 /*C_CashPlanLine.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13021 /*C_Dunning_Line_v.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13020 /*C_Dunning_Line_v.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3154 /*C_ElementValue_Trl.C_ElementValue_ID->C_ElementValue*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9579 /*C_Invoice.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9580 /*C_Invoice.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13414 /*C_InvoiceBatchLine.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13415 /*C_InvoiceBatchLine.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203468 /*C_Invoice_Header_v.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203469 /*C_Invoice_Header_v.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15853 /*C_InvoiceLine.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15854 /*C_InvoiceLine.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205557 /*C_Invoice_LineTax_v.C_InvoiceLine_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205558 /*C_Invoice_LineTax_v.C_InvoiceLine_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205625 /*C_Invoice_LineTax_v.C_Invoice_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205626 /*C_Invoice_LineTax_v.C_Invoice_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9569 /*C_Order.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9568 /*C_Order.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205785 /*C_Order_Header_v.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205786 /*C_Order_Header_v.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15849 /*C_OrderLine.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15850 /*C_OrderLine.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210184 /*C_Order_LineTax_v.C_OrderLine_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203826 /*C_Order_LineTax_v.C_OrderLine_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203913 /*C_Order_LineTax_v.C_Order_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203914 /*C_Order_LineTax_v.C_Order_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9563 /*C_Payment.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9567 /*C_Payment.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200801 /*C_PaymentTransaction.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200802 /*C_PaymentTransaction.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206576 /*C_PaySelection_Check_v.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206577 /*C_PaySelection_Check_v.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204297 /*C_PaySelection_Remittance_v.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204298 /*C_PaySelection_Remittance_v.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14587 /*C_SubAcct.C_ElementValue_ID->C_ElementValue*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1754 /*C_ValidCombination.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=1755 /*C_ValidCombination.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53921 /*DD_Order.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53922 /*DD_Order.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53960 /*DD_OrderLine.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53962 /*DD_OrderLine.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2519 /*Fact_Acct.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2534 /*Fact_Acct.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2535 /*Fact_Acct.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8253 /*Fact_Acct_Balance.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8244 /*Fact_Acct_Balance.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=8238 /*Fact_Acct_Balance.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57588 /*Fact_Acct_Summary.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57599 /*Fact_Acct_Summary.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57600 /*Fact_Acct_Summary.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11658 /*GL_Distribution.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11649 /*GL_Distribution.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11671 /*GL_Distribution.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11636 /*GL_DistributionLine.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11633 /*GL_DistributionLine.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11644 /*GL_DistributionLine.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200506 /*GL_JournalGenerator.C_ElementValueAdjustCR_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200505 /*GL_JournalGenerator.C_ElementValueAdjustDR_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200525 /*GL_JournalGeneratorLine.C_ElementValueCR_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200524 /*GL_JournalGeneratorLine.C_ElementValueDR_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200543 /*GL_JournalGeneratorSource.C_ElementValue_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200217 /*GL_JournalLine.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200227 /*GL_JournalLine.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200228 /*GL_JournalLine.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54843 /*HR_Concept_Acct.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56184 /*HR_Movement.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56183 /*HR_Movement.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7912 /*I_ElementValue.C_ElementValue_ID->C_ElementValue*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7968 /*I_ElementValue.ParentElementValue_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55434 /*I_FAJournal.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55463 /*I_FAJournal.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55462 /*I_FAJournal.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9231 /*I_GLJournal.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9245 /*I_GLJournal.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9260 /*I_GLJournal.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7936 /*I_ReportLine.C_ElementValue_ID->C_ElementValue*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9582 /*M_InOut.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9581 /*M_InOut.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207061 /*M_InOut_Header_v.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207062 /*M_InOut_Header_v.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15859 /*M_InOutLine.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=15860 /*M_InOutLine.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210205 /*M_InOut_Line_v.C_OrderLine_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207354 /*M_InOut_Line_v.C_OrderLine_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207230 /*M_InOut_Line_v.M_InOutLine_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207231 /*M_InOut_Line_v.M_InOutLine_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9588 /*M_Inventory.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9587 /*M_Inventory.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9547 /*M_Movement.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9546 /*M_Movement.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9556 /*M_Production.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9553 /*M_Production.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14838 /*PA_RatioElement.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6026 /*PA_ReportColumn.C_ElementValue_ID->C_ElementValue*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6087 /*PA_ReportSource.C_ElementValue_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53678 /*PP_Order.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53679 /*PP_Order.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58172 /*PP_Order_Header_v.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58173 /*PP_Order_Header_v.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207434 /*RV_C_Invoice.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207435 /*RV_C_Invoice.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204693 /*RV_C_InvoiceLine.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204694 /*RV_C_InvoiceLine.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207580 /*RV_C_InvoiceTax.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207581 /*RV_C_InvoiceTax.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204875 /*RV_CommissionRunDetail.C_InvoiceLine_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204876 /*RV_CommissionRunDetail.C_InvoiceLine_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205003 /*RV_CommissionRunDetail.C_Invoice_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205004 /*RV_CommissionRunDetail.C_Invoice_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210189 /*RV_CommissionRunDetail.C_OrderLine_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204835 /*RV_CommissionRunDetail.C_OrderLine_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204950 /*RV_CommissionRunDetail.C_Order_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204951 /*RV_CommissionRunDetail.C_Order_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10736 /*RV_Fact_Acct.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207736 /*RV_Fact_Acct.C_ElementValue_ID->C_ElementValue*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10726 /*RV_Fact_Acct.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10739 /*RV_Fact_Acct.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10705 /*RV_Fact_Acct_Day.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10702 /*RV_Fact_Acct_Day.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10686 /*RV_Fact_Acct_Day.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10667 /*RV_Fact_Acct_Period.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10658 /*RV_Fact_Acct_Period.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10666 /*RV_Fact_Acct_Period.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208749 /*RV_Fact_Simple.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207898 /*RV_InOutDetails.M_InOutLine_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207899 /*RV_InOutDetails.M_InOutLine_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12802 /*RV_InOutDetails.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12858 /*RV_InOutDetails.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205276 /*RV_OpenItem.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205277 /*RV_OpenItem.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210206 /*RV_OrderDetail.C_OrderLine_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208097 /*RV_OrderDetail.C_OrderLine_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208069 /*RV_OrderDetail.C_Order_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208070 /*RV_OrderDetail.C_Order_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205387 /*RV_Payment.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205388 /*RV_Payment.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208294 /*RV_Transaction.M_InOutLine_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208295 /*RV_Transaction.M_InOutLine_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14036 /*T_InvoiceGL_v.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205525 /*T_InvoiceGL_v.Fact_Acct_User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205526 /*T_InvoiceGL_v.Fact_Acct_User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14043 /*T_InvoiceGL_v.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14042 /*T_InvoiceGL_v.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59708 /*T_RV_Reconciliation.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59754 /*T_RV_Reconciliation.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59761 /*T_RV_Reconciliation.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12996 /*T_TrialBalance.Account_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12968 /*T_TrialBalance.User1_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12967 /*T_TrialBalance.User2_ID->C_ElementValue*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12615 /*C_Dunning_Line_v.C_Invoice_ID->C_Invoice*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201540 /*C_Dunning_Line_v.C_Invoice_Reversal_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=210176 /*C_Dunning_Line_v.C_Payment_C_Invoice_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203465 /*C_Invoice_Header_v.Ref_Invoice_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203466 /*C_Invoice_Header_v.Reversal_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205619 /*C_Invoice_LineTax_v.Reversal_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206529 /*C_PaySelection_Check_v.C_Payment_C_Invoice_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204237 /*C_PaySelection_Remittance_v.C_Invoice_ID->C_Invoice*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204291 /*C_PaySelection_Remittance_v.Ref_Invoice_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204292 /*C_PaySelection_Remittance_v.Reversal_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207028 /*M_InOut_Header_v.C_Invoice_ID->C_Invoice*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205534 /*M_ShippingTransaction.C_Invoice_ID->C_Invoice*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204634 /*RV_BPartnerOpen.C_Invoice_ID->C_Invoice*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207432 /*RV_C_Invoice.Reversal_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207574 /*RV_C_InvoiceTax.Reversal_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204962 /*RV_CommissionRunDetail.C_Invoice_C_Invoice_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204842 /*RV_CommissionRunDetail.C_Invoice_ID->C_Invoice*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204997 /*RV_CommissionRunDetail.Reversal_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207861 /*RV_InOutDetails.M_InOut_C_Invoice_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205270 /*RV_OpenItem.Reversal_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13090 /*RV_Payment.C_Invoice_ID->C_Invoice*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14009 /*T_InvoiceGL_v.C_Invoice_ID->C_Invoice*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205504 /*T_InvoiceGL_v.Reversal_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205471 /*T_InvoiceGL_v.T_InvoiceGL_C_Invoice_ID->C_Invoice*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13398 /*C_InvoiceBatchLine.C_InvoiceBatch_ID->C_InvoiceBatch*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201506 /*C_Dunning_Line_v.C_InvoicePaySchedule_ID->C_InvoicePaySchedule*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53249 /*C_DunningRunLine.C_InvoicePaySchedule_ID->C_InvoicePaySchedule*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13077 /*T_Aging.C_InvoicePaySchedule_ID->C_InvoicePaySchedule*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201517 /*C_Dunning_Line_v.C_Invoice_C_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201581 /*C_Dunning_Line_v.C_Payment_C_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205582 /*C_Invoice_LineTax_v.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62181 /*C_Opportunity.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205773 /*C_Order_Header_v.Link_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203892 /*C_Order_LineTax_v.Link_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203907 /*C_Order_LineTax_v.Ref_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206530 /*C_PaySelection_Check_v.C_Payment_C_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206660 /*C_Project_Details_v.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206661 /*C_Project_Details_v.C_OrderPO_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=9865 /*C_ProjectLine.C_OrderPO_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11024 /*C_RfQResponse.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56198 /*DD_Order_Header_v.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207312 /*M_InOut_Line_v.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202228 /*M_ShippingTransaction.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54027 /*PP_MRP.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204635 /*RV_BPartnerOpen.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207546 /*RV_C_InvoiceTax.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204963 /*RV_CommissionRunDetail.C_Invoice_C_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204895 /*RV_CommissionRunDetail.C_Order_C_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204793 /*RV_CommissionRunDetail.C_OrderLine_C_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204947 /*RV_CommissionRunDetail.C_Order_Ref_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204932 /*RV_CommissionRunDetail.Link_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56256 /*RV_DD_OrderDetail.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208050 /*RV_OrderDetail.Link_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208064 /*RV_OrderDetail.Ref_Order_ID->C_Order*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205375 /*RV_Payment.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53416 /*RV_PP_MRP.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14062 /*T_InvoiceGL_v.C_Order_ID->C_Order*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203810 /*C_Order_LineTax_v.Link_OrderLine_ID->C_OrderLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203821 /*C_Order_LineTax_v.Ref_OrderLine_ID->C_OrderLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207331 /*M_InOut_Line_v.Link_OrderLine_ID->C_OrderLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204843 /*RV_CommissionRunDetail.C_InvoiceLine_C_OrderLine_ID->C_OrderLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204815 /*RV_CommissionRunDetail.C_OrderLine_M_Shipper_ID->C_OrderLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204828 /*RV_CommissionRunDetail.C_OrderLine_Ref_OrderLine_ID->C_OrderLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204812 /*RV_CommissionRunDetail.Link_OrderLine_ID->C_OrderLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208085 /*RV_OrderDetail.Link_OrderLine_ID->C_OrderLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208268 /*RV_Transaction.M_InOutLine_C_OrderLine_ID->C_OrderLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54090 /*C_CashLine.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208437 /*C_DepositBatchLine.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201518 /*C_Dunning_Line_v.C_Invoice_C_Payment_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201501 /*C_Dunning_Line_v.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201607 /*C_Dunning_Line_v.C_Payment_Reversal_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201606 /*C_Dunning_Line_v.Ref_Payment_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203446 /*C_Invoice_Header_v.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205583 /*C_Invoice_LineTax_v.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205751 /*C_Order_Header_v.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203856 /*C_Order_LineTax_v.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13705 /*C_Payment.Ref_Payment_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55309 /*C_Payment.Reversal_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14327 /*C_PaymentAllocate.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206489 /*C_PaySelection_Check_v.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206563 /*C_PaySelection_Check_v.C_Payment_Reversal_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206562 /*C_PaySelection_Check_v.Ref_Payment_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204260 /*C_PaySelection_Remittance_v.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204636 /*RV_BPartnerOpen.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204645 /*RV_BPartnerOpen.Reversal_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207420 /*RV_C_Invoice.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207547 /*RV_C_InvoiceTax.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204964 /*RV_CommissionRunDetail.C_Invoice_C_Payment_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204896 /*RV_CommissionRunDetail.C_Order_C_Payment_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205243 /*RV_OpenItem.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208019 /*RV_OrderDetail.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205383 /*RV_Payment.Ref_Payment_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205384 /*RV_Payment.Reversal_ID->C_Payment*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205482 /*T_InvoiceGL_v.C_Payment_ID->C_Payment*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201582 /*C_Dunning_Line_v.C_PaymentBatch_ID->C_PaymentBatch*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5300 /*C_Payment.C_PaymentBatch_ID->C_PaymentBatch*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200737 /*C_PaymentTransaction.C_PaymentBatch_ID->C_PaymentBatch*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206531 /*C_PaySelection_Check_v.C_PaymentBatch_ID->C_PaymentBatch*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13157 /*RV_Payment.C_PaymentBatch_ID->C_PaymentBatch*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7670 /*C_PaySelectionCheck.C_PaySelection_ID->C_PaySelection*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5635 /*C_PaySelectionLine.C_PaySelection_ID->C_PaySelection*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54859 /*HR_Process.C_PaySelection_ID->C_PaySelection*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7736 /*C_PaySelectionLine.C_PaySelectionCheck_ID->C_PaySelectionCheck*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11059 /*C_RfQLine.C_RfQ_ID->C_RfQ*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11026 /*C_RfQResponse.C_RfQ_ID->C_RfQ*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12010 /*C_RfQResponse_v.C_RfQ_ID->C_RfQ*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11718 /*RV_C_RfQResponse.C_RfQ_ID->C_RfQ*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11704 /*RV_C_RfQ_UnAnswered.C_RfQ_ID->C_RfQ*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10999 /*C_RfQResponseLineQty.C_RfQLineQty_ID->C_RfQLineQty*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12025 /*C_RfQResponseLineQty_v.C_RfQLineQty_ID->C_RfQLineQty*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12054 /*C_RfQResponseLine_v.C_RfQLineQty_ID->C_RfQLineQty*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11443 /*C_RfQResponseLine.C_RfQResponse_ID->C_RfQResponse*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12041 /*C_RfQResponseLine_v.C_RfQResponse_ID->C_RfQResponse*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12042 /*C_RfQResponse_v.C_RfQResponse_ID->C_RfQResponse*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11728 /*RV_C_RfQResponse.C_RfQResponse_ID->C_RfQResponse*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12045 /*C_RfQResponseLineQty_v.C_RfQResponseLineQty_ID->C_RfQResponseLineQty*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12050 /*C_RfQResponseLine_v.C_RfQResponseLineQty_ID->C_RfQResponseLineQty*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14494 /*C_TaxDeclarationAcct.C_TaxDeclaration_ID->C_TaxDeclaration*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14476 /*C_TaxDeclarationLine.C_TaxDeclaration_ID->C_TaxDeclaration*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59777 /*Fact_Reconciliation.Fact_Acct_ID->Fact_Acct*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14038 /*T_InvoiceGL_v.Fact_Acct_ID->Fact_Acct*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5984 /*C_RevenueRecognition_Run.GL_Journal_ID->GL_Journal*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55306 /*GL_Journal.Reversal_ID->GL_Journal*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55959 /*A_Asset_Addition.GL_JournalBatch_ID->GL_JournalBatch*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55307 /*GL_JournalBatch.Reversal_ID->GL_JournalBatch*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58973 /*I_HR_Movement.HR_Movement_ID->HR_Movement*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55033 /*HR_Movement.HR_Process_ID->HR_Process*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55310 /*HR_Process.Reversal_ID->HR_Process*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58959 /*I_HR_Movement.HR_Process_ID->HR_Process*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59466 /*A_Asset_Addition.I_FixedAsset_ID->I_FixedAsset*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207055 /*M_InOut_Header_v.Ref_InOut_ID->M_InOut*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207056 /*M_InOut_Header_v.Reversal_ID->M_InOut*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10876 /*M_Package.M_InOut_ID->M_InOut*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202198 /*M_ShippingTransaction.M_InOut_ID->M_InOut*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207879 /*RV_InOutDetails.Reversal_ID->M_InOut*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208281 /*RV_Transaction.M_InOutLine_M_InOut_ID->M_InOut*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12103 /*M_InOutLineConfirm.M_InOutConfirm_ID->M_InOutConfirm*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207227 /*M_InOut_Line_v.ReversalLine_ID->M_InOutLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10249 /*M_TransactionAllocation.Out_M_InOutLine_ID->M_InOutLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207897 /*RV_InOutDetails.ReversalLine_ID->M_InOutLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208328 /*RV_Transaction.C_PrjctIssue_M_InOutLine_ID->M_InOutLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55304 /*M_Inventory.Reversal_ID->M_Inventory*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3563 /*M_InventoryLine.M_Inventory_ID->M_Inventory*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56357 /*M_InventoryLine.ReversalLine_ID->M_InventoryLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10246 /*M_TransactionAllocation.Out_M_InventoryLine_ID->M_InventoryLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208289 /*RV_Transaction.M_InOutLine_ReversalLine_ID->M_InventoryLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208240 /*RV_Transaction.M_InventoryLine_RevLine_ID->M_InventoryLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200881 /*M_MatchInv.Reversal_ID->M_MatchInv*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200880 /*M_MatchPO.Reversal_ID->M_MatchPO*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55308 /*M_Movement.Reversal_ID->M_Movement*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3590 /*M_MovementLine.M_Movement_ID->M_Movement*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=12426 /*M_MovementLineConfirm.M_MovementConfirm_ID->M_MovementConfirm*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56356 /*M_MovementLine.ReversalLine_ID->M_MovementLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208257 /*RV_Transaction.M_MovementLine_ReversalLn_ID->M_MovementLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10866 /*M_PackageLine.M_Package_ID->M_Package*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201191 /*M_PackageMPS.M_Package_ID->M_Package*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202230 /*M_ShippingTransaction.M_Package_ID->M_Package*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201210 /*M_PackageLine.M_PackageMPS_ID->M_PackageMPS*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205536 /*M_ShippingTransactionLine.M_PackageMPS_ID->M_PackageMPS*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59273 /*A_Asset_Product.M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11276 /*B_TopicType.M_ProductMember_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205541 /*C_Invoice_LineTax_v.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203799 /*C_Order_LineTax_v.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203983 /*C_Order_LineTax_v.M_Product_PO_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206748 /*C_Project_Details_v.M_Product_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=206864 /*C_Project_Header_v.C_Phase_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57590 /*Fact_Acct_Summary.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56956 /*I_PriceList.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=7841 /*I_Product.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=200048 /*M_CostMovement_v.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207333 /*M_InOut_Line_v.C_OrderLine_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207210 /*M_InOut_Line_v.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=2565 /*M_Product_Acct.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=3321 /*M_Product_Trl.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6029 /*PA_ReportColumn.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6090 /*PA_ReportSource.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57383 /*PP_Order_BOM_Header_v.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57397 /*PP_Order_BOMLine_v.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58145 /*PP_Order_Header_v.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53389 /*PP_Product_Planning.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14737 /*R_RequestAction.M_ProductSpent_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13992 /*R_RequestUpdate.M_ProductSpent_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204731 /*RV_C_InvoiceLine.M_Product_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14690 /*RV_C_Invoice_ProductMonth.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14677 /*RV_C_Invoice_ProductQtr.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14153 /*RV_CostDetail.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56272 /*RV_DD_OrderDetail.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56126 /*RV_M_Forecast.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56143 /*RV_M_Forecast_Period.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208729 /*RV_M_Product_WhereUsed_V.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207992 /*RV_M_Transaction.M_Product_PO_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4406 /*RV_M_Transaction_Sum.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53431 /*RV_PP_MRP.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56101 /*RV_PP_Order_BOMLine.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=58673 /*RV_Storage_Per_Product.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208332 /*RV_Transaction.C_PrjctIssue_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208283 /*RV_Transaction.M_InOutLine_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208234 /*RV_Transaction.M_InventoryLine_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208255 /*RV_Transaction.M_MovementLine_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208304 /*RV_Transaction.M_ProductionLine_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208316 /*RV_Transaction.M_ProductionPlan_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=62027 /*T_BOM_Indented.Sel_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56641 /*T_BOMLine_Costs.M_Product_ID->M_Product*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56653 /*T_BOMLine_Costs.TM_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205521 /*T_InvoiceGL_v.Fact_Acct_M_Product_ID->M_Product*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=211207 /*M_Production.Reversal_ID->M_Production*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=59960 /*M_ProductionLine.M_Production_ID->M_Production*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4762 /*M_ProductionPlan.M_Production_ID->M_Production*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10245 /*M_TransactionAllocation.Out_M_ProductionLine_ID->M_ProductionLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208305 /*RV_Transaction.M_ProductionL_M_ProductionL_ID->M_ProductionLine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=4753 /*M_ProductionLine.M_ProductionPlan_ID->M_ProductionPlan*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11499 /*M_RequisitionLine.M_Requisition_ID->M_Requisition*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54045 /*PP_MRP.M_Requisition_ID->M_Requisition*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=11761 /*RV_M_Requisition.M_Requisition_ID->M_Requisition*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53433 /*RV_PP_MRP.M_Requisition_ID->M_Requisition*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=201534 /*C_Dunning_Line_v.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=203460 /*C_Invoice_Header_v.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205612 /*C_Invoice_LineTax_v.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204285 /*C_PaySelection_Remittance_v.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207048 /*M_InOut_Header_v.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10832 /*M_RMALine.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13582 /*R_RequestAction.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207428 /*RV_C_Invoice.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207567 /*RV_C_InvoiceTax.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204990 /*RV_CommissionRunDetail.C_Invoice_M_RMA_ID->M_RMA*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207875 /*RV_InOutDetails.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205263 /*RV_OpenItem.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=205497 /*T_InvoiceGL_v.M_RMA_ID->M_RMA*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57791 /*M_RMALine.Ref_RMALine_ID->M_RMALine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=204860 /*RV_CommissionRunDetail.C_InvoiceLine_M_RMALine_ID->M_RMALine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208284 /*RV_Transaction.M_InOutLine_M_RMALine_ID->M_RMALine*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=202303 /*M_ShippingTransactionLine.M_ShippingTransaction_ID->M_ShippingTransaction*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=10243 /*M_TransactionAllocation.Out_M_Transaction_ID->M_Transaction*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207919 /*RV_M_Transaction.M_Transaction_ID->M_Transaction*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=56532 /*C_OrderLine.PP_Cost_Collector_ID->PP_Cost_Collector*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=57008 /*HR_Movement.PP_Cost_Collector_ID->PP_Cost_Collector*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=53409 /*M_Transaction.PP_Cost_Collector_ID->PP_Cost_Collector*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=55311 /*PP_Cost_Collector.Reversal_ID->PP_Cost_Collector*/ and ad_reference_id=18/*Table*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=54319 /*PP_Cost_CollectorMA.PP_Cost_Collector_ID->PP_Cost_Collector*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207659 /*RV_CostDetail.PP_Cost_Collector_ID->PP_Cost_Collector*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=207920 /*RV_M_Transaction.PP_Cost_Collector_ID->PP_Cost_Collector*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=208169 /*RV_Transaction.PP_Cost_Collector_ID->PP_Cost_Collector*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14903 /*R_IssueKnown.R_IssueRecommendation_ID->R_IssueRecommendation*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=14905 /*R_IssueKnown.R_Request_ID->R_Request*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=5449 /*R_RequestAction.R_Request_ID->R_Request*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13986 /*R_RequestUpdate.R_Request_ID->R_Request*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=13712 /*R_RequestUpdates.R_Request_ID->R_Request*/ and ad_reference_id=19/*Table Direct*/
;

UPDATE ad_column SET ad_reference_id=30/*Search*/ WHERE ad_column_id=6880 /*S_TimeExpenseLine.S_TimeExpense_ID->S_TimeExpense*/ and ad_reference_id=19/*Table Direct*/
;

SELECT register_migration_script('202006251318_IDEMPIERE-1052.sql') FROM dual
;

