SET SQLBLANKLINES ON
SET DEFINE OFF

-- IDEMPIERE-4157 Quick Form
-- Feb 26, 2020, 7:18:08 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:18:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=1120
;

-- Feb 26, 2020, 7:18:16 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:18:16','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=1127
;

-- Feb 26, 2020, 7:18:28 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:18:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=1126
;

-- Feb 26, 2020, 7:18:31 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:18:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10828
;

-- Feb 26, 2020, 7:18:42 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:18:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10829
;

-- Feb 26, 2020, 7:26:05 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:26:05','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=4124
;

-- Feb 26, 2020, 7:26:07 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:26:07','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=4012
;

-- Feb 26, 2020, 7:26:20 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:26:20','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=8690
;

-- Feb 26, 2020, 7:26:32 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:26:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=4125
;

-- Feb 26, 2020, 7:27:53 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:27:53','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=4010
;

-- Feb 26, 2020, 7:27:56 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:27:56','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=4126
;

-- Feb 26, 2020, 7:28:04 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:28:04','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=4011
;

-- Feb 26, 2020, 7:28:06 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:28:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=4009
;

-- Feb 26, 2020, 7:28:11 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:28:11','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=4013
;

-- Feb 26, 2020, 7:29:22 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:29:22','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=200216
;

-- Feb 26, 2020, 7:29:25 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:29:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=200217
;

-- Feb 26, 2020, 7:29:44 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:29:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=200223
;

-- Feb 26, 2020, 7:29:47 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:29:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=200224
;

-- Feb 26, 2020, 7:30:14 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:30:14','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=200231
;

-- Feb 26, 2020, 7:30:25 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:30:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=200240
;

-- Feb 26, 2020, 7:30:34 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:30:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=200244
;

-- Feb 26, 2020, 7:30:37 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:30:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=200245
;

-- Feb 26, 2020, 7:31:18 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:31:18','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10989
;

-- Feb 26, 2020, 7:31:21 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:31:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10990
;

-- Feb 26, 2020, 7:31:24 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:31:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10991
;

-- Feb 26, 2020, 7:31:30 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:31:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10992
;

-- Feb 26, 2020, 7:31:33 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:31:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10995
;

-- Feb 26, 2020, 7:31:37 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:31:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10998
;

-- Feb 26, 2020, 7:31:39 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:31:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10997
;

-- Feb 26, 2020, 7:32:08 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:32:08','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2952
;

-- Feb 26, 2020, 7:32:16 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:32:16','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2731
;

-- Feb 26, 2020, 7:32:24 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:32:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2737
;

-- Feb 26, 2020, 7:32:29 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:32:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6571
;

-- Feb 26, 2020, 7:32:32 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:32:32','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12097
;

-- Feb 26, 2020, 7:32:34 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:32:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2733
;

-- Feb 26, 2020, 7:32:36 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:32:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2734
;

-- Feb 26, 2020, 7:32:39 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:32:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2738
;

-- Feb 26, 2020, 7:32:48 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='N',Updated=TO_DATE('2020-02-26 19:32:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12097
;

-- Feb 26, 2020, 7:33:47 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:33:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2994
;

-- Feb 26, 2020, 7:33:51 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:33:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2996
;

-- Feb 26, 2020, 7:33:55 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:33:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2984
;

-- Feb 26, 2020, 7:34:06 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:34:06','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2991
;

-- Feb 26, 2020, 7:34:17 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:34:17','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10821
;

-- Feb 26, 2020, 7:34:21 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:34:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10822
;

-- Feb 26, 2020, 7:34:46 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:34:46','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3369
;

-- Feb 26, 2020, 7:34:50 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:34:50','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3371
;

-- Feb 26, 2020, 7:34:53 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:34:53','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3360
;

-- Feb 26, 2020, 7:34:57 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:34:57','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3366
;

-- Feb 26, 2020, 7:35:03 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:35:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10823
;

-- Feb 26, 2020, 7:35:09 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:35:09','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10824
;

-- Feb 26, 2020, 7:36:25 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:36:25','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3521
;

-- Feb 26, 2020, 7:36:27 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:36:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3518
;

-- Feb 26, 2020, 7:36:29 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:36:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3515
;

-- Feb 26, 2020, 7:36:31 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:36:31','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6536
;

-- Feb 26, 2020, 7:36:33 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:36:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3514
;

-- Feb 26, 2020, 7:36:34 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:36:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=11255
;

-- Feb 26, 2020, 7:36:38 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:36:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3510
;

-- Feb 26, 2020, 7:36:41 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:36:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10825
;

-- Feb 26, 2020, 7:36:55 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='N',Updated=TO_DATE('2020-02-26 19:36:55','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=11255
;

-- Feb 26, 2020, 7:38:00 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:38:00','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12226
;

-- Feb 26, 2020, 7:38:03 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:38:03','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12231
;

-- Feb 26, 2020, 7:38:10 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='N',Updated=TO_DATE('2020-02-26 19:38:10','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12231
;

-- Feb 26, 2020, 7:38:12 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:38:12','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12223
;

-- Feb 26, 2020, 7:38:15 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:38:15','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12225
;

-- Feb 26, 2020, 7:38:16 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:38:16','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12230
;

-- Feb 26, 2020, 7:38:20 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:38:20','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12228
;

-- Feb 26, 2020, 7:38:24 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:38:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=12232
;

-- Feb 26, 2020, 7:39:21 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:39:21','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2926
;

-- Feb 26, 2020, 7:39:24 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:39:24','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2696
;

-- Feb 26, 2020, 7:39:27 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:39:27','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2697
;

-- Feb 26, 2020, 7:39:30 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:39:30','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6555
;

-- Feb 26, 2020, 7:39:35 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:39:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2699
;

-- Feb 26, 2020, 7:39:41 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:39:41','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2698
;

-- Feb 26, 2020, 7:39:42 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:39:42','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2692
;

-- Feb 26, 2020, 7:39:45 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:39:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=8290
;

-- Feb 26, 2020, 7:39:51 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:39:51','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=8289
;

-- Feb 26, 2020, 7:41:28 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:41:28','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3403
;

-- Feb 26, 2020, 7:41:33 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:41:33','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3386
;

-- Feb 26, 2020, 7:41:35 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:41:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3413
;

-- Feb 26, 2020, 7:41:37 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:41:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6535
;

-- Feb 26, 2020, 7:41:39 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:41:39','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3398
;

-- Feb 26, 2020, 7:41:47 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:41:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10826
;

-- Feb 26, 2020, 7:41:48 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:41:48','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=3387
;

-- Feb 26, 2020, 7:41:54 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:41:54','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10827
;

-- Feb 26, 2020, 7:42:35 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:42:35','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2117
;

-- Feb 26, 2020, 7:42:38 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:42:38','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6570
;

-- Feb 26, 2020, 7:42:45 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:42:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=1128
;

-- Feb 26, 2020, 7:43:29 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:43:29','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2949
;

-- Feb 26, 2020, 7:43:34 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:43:34','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2718
;

-- Feb 26, 2020, 7:43:36 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:43:36','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=6542
;

-- Feb 26, 2020, 7:43:37 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:43:37','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2717
;

-- Feb 26, 2020, 7:43:44 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:43:44','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2713
;

-- Feb 26, 2020, 7:43:45 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:43:45','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=10830
;

-- Feb 26, 2020, 7:43:47 PM CET
UPDATE AD_Field SET AD_Reference_Value_ID=NULL, AD_Val_Rule_ID=NULL, IsToolbarButton=NULL, IsQuickForm='Y',Updated=TO_DATE('2020-02-26 19:43:47','YYYY-MM-DD HH24:MI:SS'),UpdatedBy=100 WHERE AD_Field_ID=2948
;

SELECT register_migration_script('202002261947_IDEMPIERE-4157_Config.sql') FROM dual
;

